<!-- This document was generated with the assistance of an AI coding tool. -->
# Lane 15 Wave 12 — fail-closed IFC evidence gate (LOCAL_ONLY)

**2026-10-15 UTC · downstream sandbox only.** No global worker lease acquired, no commits or GitHub writes, no default-branch merge, and no upstream publication. The canonical project registration is still draft `kvnloo/oss-factory` PR #100; issue #104 is the existing coordination surface.

## Reproduced deficiency (our prototype, not IfcOpenShell)

In Wave 11, `runtime_gate.check_case()` labeled `ifc_authoring=PASS` solely when `run_ifc()` returned `runtime_checks.geometry_kernel=PASS`. A synthetic kernel-only receipt with **no IFC file, no schema validation, and no saved/reopened round-trip** therefore produced a false-positive `PASS`, and could pass through `TOPOLOGY_READY_ONLY` for boundary handoff. The separate Civilization gate still remained UNVERIFIED.

Wave 12 checks **all** of: `status=ifc_authoring_verified`, `ifc_roundtrip=PASS`, `schema_validation=PASS`, `geometry_kernel=PASS`, `verified.schema=IFC4`, 6 validated kernel bodies, zero schema validation errors, metre-based file scale, existence of `single_zone.ifc`, and exact reported SHA-256. Until that receipt is complete, IFC authoring and its dependent boundary handoff stay `NOT_RUN`. A matching *synthetic* receipt is tested only to verify the gate logic; it **does not establish actual native IFC capability**.

Source-backed requirement: [factory AGENTS](https://github.com/kvnloo/oss-factory/blob/main/AGENTS.md), [control plane](https://github.com/kvnloo/oss-factory/blob/main/factory/CONTROL_PLANE.md), [HITL](https://github.com/kvnloo/oss-factory/blob/main/factory/HITL.md), and the scoped [Lane 15 issue #104](https://github.com/kvnloo/oss-factory/issues/104) forbid claims not supported by actual engine execution.

## Reproduce

Run these from the ZIP root (Python 3.13.5; NumPy 2.3.5, trimesh 4.11.1, pytest 9.0.2 used here):

```sh
python repro_gate_delta.py
python -m unittest discover -s . -p 'test_*.py' -v
(cd baseline && python -m unittest discover -s . -p 'test_*.py' -v)
python -m pytest -q test_ifc_units.py
python runtime_gate.py benchmarks/small_residence benchmarks/field_clinic benchmarks/workshop --report /tmp/lane15-wave12-runtime.json --author-ifc
```

Observed reproduction: Wave11 `ifc_authoring=PASS` / `ifc_energy_boundary_handoff=TOPOLOGY_READY_ONLY` on an intentionally incomplete stub; Wave12 both `NOT_RUN`. Root suite: **79 passed, 1 skipped** (80 tests total); baseline: **10 passed**; pytest IFC-units selection: **5 passed, 1 skipped, 38 subtests passed** (overlaps root, not additional coverage). Three geometry-only building preflights passed; **0 actual IFC/thermal/USD/Civ capabilities verified**.

The only two changed source files are `runtime_gate.py` and `test_runtime_gate.py`. See `wave12-local.patch`. `provenance/runtime_gate_wave11.py` is a read-only comparison snapshot, not production code.

## Limits and next proof

- No native `ifcopenshell`, Bonsai, `pxr`, or EnergyPlus runtime found. DNS prevented package acquisition. No IFC model was created; no independent IFC kernel or ENERGYPLUS parser/simulation run occurred.
- Geometry-only `single_zone_geometry.idf` contains undefined construction placeholders. It is **not** a valid energy simulation. Energy demand, cost, embodied-carbon and savings remain unknown/null.
- Next: on an authorized compatible machine, generate/reopen real IFC4 `m`/`mm` variants, validate six solids and space-boundary geometry with IfcOpenShell, then inspect in Bonsai. Independently parse the USDA with `pxr`, complete a valid EnergyPlus model (including materials, constructions, schedules, and weather), and run the engine before setting any Civilization capability verified.

## Credit, license, dedupe

Upstream [IfcOpenShell #9295](https://github.com/IfcOpenShell/IfcOpenShell/pull/9295) by **BIMvoice** addresses the independent `IfcProjectLibrary` geometry-unit defect documented in [#9294](https://github.com/IfcOpenShell/IfcOpenShell/issues/9294) and [#9926](https://github.com/IfcOpenShell/IfcOpenShell/issues/9926); this wave does not modify or duplicate it. Original IfcOpenShell source is under LGPL-3.0-or-later, Bonsai under GPL-3.0-or-later, with explicit upstream AI-disclosure instructions. This sandbox patch is AI-assisted and must undergo project license/contribution review before any promotion.

Trade route preserved: **Manufacturing → IFC/Bonsai → OpenUSD → EnergyPlus → Civilization**. This wave improves evidence integrity only, not measured energy or geometry performance.
