# This file was generated with the assistance of an AI coding tool.
"""Demonstrate Wave11 false-PASS and Wave12 fail-closed behavior with a synthetic stub.

The stub deliberately does not create an IFC file or run IfcOpenShell.
"""
from __future__ import annotations

import json
from pathlib import Path
import sys
from tempfile import TemporaryDirectory
from unittest.mock import patch

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE / "baseline"))
from export_surfaces import export
from runtime_gate import check_case


def main():
    old = (BASE / "provenance" / "runtime_gate_wave11.py").read_text()
    old_globals = {"__name__": "wave11_unsafe_snapshot", "__file__": str(BASE / "runtime_gate.py")}
    exec(compile(old, "wave11/runtime_gate.py", "exec"), old_globals)
    fake = {"runtime_checks": {"geometry_kernel": "PASS"},
            "energy_space_boundary_audit": {"status": "TOPOLOGY_READY_ONLY"}}
    with TemporaryDirectory() as temp:
        folder = Path(temp) / "residence"
        export(folder, 6, 8, 2.7)
        old_globals["run_ifc"] = lambda *args, **kwargs: fake
        prior = old_globals["check_case"](folder, allow_ifc_author=True)
        with patch("runtime_gate.run_ifc", return_value=fake):
            current = check_case(folder, allow_ifc_author=True)
        result = {
            "test_only": True,
            "native_ifc_written": False,
            "wave11_ifc_authoring_status": prior["ifc_authoring"]["status"],
            "wave12_ifc_authoring_status": current["ifc_authoring"]["status"],
            "wave11_boundary_status": prior["ifc_energy_boundary_handoff"]["status"],
            "wave12_boundary_status": current["ifc_energy_boundary_handoff"]["status"],
        }
    assert result["wave11_ifc_authoring_status"] == "PASS"
    assert result["wave12_ifc_authoring_status"] == "NOT_RUN"
    assert result["wave12_boundary_status"] == "NOT_RUN"
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
