# Lane 15: synthetic single-zone BIM interoperability preflight

Generated with the assistance of an AI coding tool. This is **downstream research**, not a verified upstream bug fix or an EnergyPlus performance result.

## Purpose

Check the geometric handoff between a simplified IFC4 building, a zero-thickness OpenUSD reference shell, and EnergyPlus `BuildingSurface:Detailed` input. A 10 m × 8 m × 3 m nominal zone has six outward-oriented surfaces and analytic reference quantities: **80 m² floor, 108 m² gross wall, 268 m² total envelope, 240 m³ reference volume**. Those are *synthetic geometry*, not as-built measurement.

The IFC adapter creates a project/site/building/storey, an `IfcSpace`, four `IfcWall` products and two `IfcSlab` products using **IfcOpenShell's official Python API**, not a handwritten STEP encoder. Unlike the reference shell, IFC walls and slabs have physical thickness; **their boundary surfaces will not exactly coincide** with the EnergyPlus polygons. Aligning boundaries/voids is a follow-on task, not silently assumed.

## Reproduce

```bash
python -m unittest discover -s . -p 'test_*.py' -v
python lane15.py --out out
# On a workstation with the packages installed:
python -m pip install ifcopenshell==0.9.0 numpy
python lane15.py --out out --with-ifc
```

Generated (dependency-free): `out/single_zone.usda` (ASCII OpenUSD geometry), `out/single_zone_geometry.idf` (**geometry fragment only**, unresolved construction placeholders; not simulation-ready), `out/metrics.json`. Optional IFC: `out/single_zone.ifc`.

## Validation tiers

1. **Executed locally:** pure-Python geometry tests, surface orientation, divergence-theorem volume, 6-face format population, deterministic re-generation. These do not prove the outputs parse in OpenUSD/EnergyPlus.
2. **Required on capable worker:** use IfcOpenShell 0.9.0 to generate and reopen `single_zone.ifc`; inspect with Bonsai. Compare geometry-kernel bounding boxes/volumes and ensure SI units. Validate the IFC with IfcOpenShell's schema validator and IFC4 model-view rules.
3. **Required before calling it interoperable:** open `.usda` with OpenUSD, parse/load `.idf` with EnergyPlus, supply weather/material/construction/schedules, confirm each surface's geometry and adjacency, and resolve internal vs external reference-face thickness offsets.
4. **Required before claiming energy impact:** run a documented EnergyPlus version + EPW/weather + calibrated schedules and HVAC, hold inputs fixed across baselines, record loads/consumption with confidence limits.

## Existing upstream work / dedupe

- [IfcOpenShell #9294](https://github.com/IfcOpenShell/IfcOpenShell/issues/9294): `IfcProjectLibrary` causes loss of SI unit detection and severe geometry performance regression; [PR #9295](https://github.com/IfcOpenShell/IfcOpenShell/pull/9295) is already open (author **BIMvoice**). **Do not create a duplicate fix.**
- [IfcOpenShell #9926](https://github.com/IfcOpenShell/IfcOpenShell/issues/9926): independent 0.9.0 report of same mixed context issue.
- [IfcOpenShell AGENTS.md](https://github.com/IfcOpenShell/IfcOpenShell/blob/v0.9.0/AGENTS.md): upstream mandates AI disclosure, small PRs, format/lint/tests, LGPL-3.0-or-later for libraries and GPL-3.0-or-later for Bonsai.
- [IfcOpenShell 0.9.0 announcement](https://github.com/IfcOpenShell/IfcOpenShell/discussions/9759): updated architecture requires fresh API and geometry validation.

**Provenance:** synthetic geometry and scripts generated for Lane 15 with AI assistance. Upstream issue diagnosis and existing PR credit to **BIMvoice** and the original issue/report authors. No developer, maintainer, or test author should be implied to have endorsed this fixture.

## Next highest-value task

On a capable local worker, run `--with-ifc`, validate the source export with IfcOpenShell 0.9.0, and perform an independent source-level review of #9295 for the existing project/library unit-selection requirement (do not duplicate). Then add *IfcRelSpaceBoundary* and glazed openings, validate adjacency, and only then run EnergyPlus.
