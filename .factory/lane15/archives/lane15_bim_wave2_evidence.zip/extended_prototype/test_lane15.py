# This file was generated with the assistance of an AI coding tool.
"""Unit tests for the dependency-free part of the Lane 15 BIM handoff."""

import json
import math
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from lane15 import Building, area, area_vector, build, quantities, shell, signed_enclosed_volume


class GeometryTests(unittest.TestCase):
    def test_expected_areas(self):
        b = Building()
        d = quantities(b)
        self.assertEqual(d["floor_area_m2"], 80.0)
        self.assertEqual(d["roof_area_m2"], 80.0)
        self.assertEqual(d["wall_area_m2"], 108.0)
        self.assertEqual(d["envelope_area_m2"], 268.0)

    def test_expected_signed_volume(self):
        self.assertAlmostEqual(signed_enclosed_volume(shell(Building())), 240.0)

    def test_outward_normals(self):
        expected = {"Floor": (0, 0, -1), "Roof": (0, 0, 1), "South": (0, -1, 0),
                    "North": (0, 1, 0), "East": (1, 0, 0), "West": (-1, 0, 0)}
        for s in shell(Building()):
            self.assertEqual(tuple(round(v / area(s)) for v in area_vector(s)), expected[s.name])

    def test_six_faces_nonzero(self):
        b = Building()
        self.assertEqual(len(shell(b)), 6)
        self.assertTrue(all(area(s) > 0 for s in shell(b)))

    def test_nondefault_dimensions(self):
        b = Building(length_m=5.0, width_m=4.0, height_m=2.0)
        self.assertEqual(quantities(b)["enclosed_volume_m3"], 40.0)
        self.assertEqual(quantities(b)["envelope_area_m2"], 2 * (20 + 10 + 8))

    def test_bad_dimensions_rejected(self):
        for value in (0, -3, float("nan"), float("inf")):
            with self.subTest(value=value), self.assertRaises(ValueError):
                Building(length_m=value)

    def test_unrealistic_wall_rejected(self):
        with self.assertRaises(ValueError):
            Building(wall_thickness_m=4.0)

    def test_no_unmeasured_energy_claim(self):
        self.assertIsNone(quantities(Building())["energy_demand_kwh"])

    def test_generate_formats_and_consistent_counts(self):
        with TemporaryDirectory() as tmp:
            dest = Path(tmp)
            build(dest)
            usda = (dest / "single_zone.usda").read_text()
            idf = (dest / "single_zone_geometry.idf").read_text()
            stats = json.loads((dest / "metrics.json").read_text())
            self.assertEqual(usda.count('def Mesh "'), 6)
            self.assertEqual(idf.count("BuildingSurface:Detailed,"), 6)
            self.assertIn('metersPerUnit = 1', usda)
            self.assertIn("CounterClockWise", idf)
            self.assertIn("NOT a run-ready EnergyPlus simulation", idf)
            self.assertEqual(stats["enclosed_volume_m3"], 240.0)
            self.assertFalse((dest / "single_zone.ifc").exists())

    def test_reproducible_files(self):
        with TemporaryDirectory() as tmp:
            a, b = Path(tmp) / "a", Path(tmp) / "b"
            build(a)
            build(b)
            for name in ("single_zone.usda", "single_zone_geometry.idf", "metrics.json"):
                self.assertEqual((a / name).read_bytes(), (b / name).read_bytes())


if __name__ == "__main__":
    unittest.main()
