<!-- This document was generated with the assistance of an AI coding tool. -->
<!-- oss-factory:v1
{"id":"20261015-lane15-ifc-single-shell-020","kind":"result","project":"oss-factory","from":"chatgpt","to":["factory"],"status":"done","civ":{"city_id":"oss:oss-factory"},"parent_id":"20261014-lane15-ifc-preflight-001","dedupe_key":"lane15-ifc-single-zone-interoperability"}
-->

# Lane 15 — Wave 20: reject disconnected IFC material shells

**Disposition: LOCAL_ONLY / LIMITED.** Reusable patch and tests in an isolated local artifact; no GitHub writes, six-worker lease, origin action, merge, energy consumption measurement or verified construction benefit. Continue on existing [factory issue #104](https://github.com/kvnloo/oss-factory/issues/104), not a duplicate. Project registration remains on unmerged [draft #100](https://github.com/kvnloo/oss-factory/pull/100).

## One concrete local false positive fixed

Wave 19's triangle-edge closure, bounding-box and signed-volume checks could accept *two separate, overlapping closed material shells* as one rectangular solid. Example: two boxes whose union has bounding box `[0,1]³` and whose **summed** signed volumes equal **1.0 m³**, while their physical union occupies only about **0.8667 m³**. A second failure mode: two individually closed cubes touching only at one vertex could be mislabeled one connected shell by naive vertex-graph traversal. Neither geometry is one physical rectangular material body.

`mesh_volume_gate.py` now checks connectedness through **shared triangle edges** after its existing directed-edge manifold check. A point of contact does not connect separate surface components. `verify_ifc()` records `kernel_single_shell_bodies` for the six authored IFC4 walls/slabs; `runtime_gate.validated_ifc_receipt()` requires all six proven single-shell, rejecting older or incomplete receipts. This is a **fixed synthetic fixture preflight**, not a general-purpose IFC validity predicate: curved walls, multipart construction, openings, vertex tolerance calibration and self-intersection detection remain outside scope. In particular, edge-connected self-intersections can still escape this check.

## Evidence — independent red / green controls, October 15, 2026

| Observation | Wave 19 | Wave 20 |
| --- | ---: | ---: |
| 256 valid boxes accepted | 256 | 256 |
| 256 overlapping disconnected solids falsely accepted | 256 | **0** |
| 256 corner-contacting double shells falsely accepted | 256 | **0** |
| Disconnected/point-contact cases correctly rejected | 0/512 | **512/512** |
| Core unittest discovery | 105 collected, 1 skipped | **109 collected, 1 skipped** |
| Independent baseline tests | 19 passed | **19 passed** |
| Total tests passing | 123 | **127**, 1 skipped |
| Clean apply on unmodified Wave 19 archive | — | **127 passed, 1 skipped** |
| Three geometry-only building preflights | PASS | **PASS** |
| Native IFC, Bonsai, OpenUSD, EnergyPlus | NOT_RUN | **NOT_RUN** |
| Energy consumption | unknown | **unknown** |

Synthetic randomized matrix: **seed 1520**, 256 independent dimension/offset selections per class, scaled box extents, worst valid-cuboid relative volume error `7.49e-14`. This is a correctness characterization of ideal meshes only; it does not demonstrate any runtime acceleration, realistic model success rate or energy savings. Red control imports the original Wave 19 validator unchanged from the ZIP; green control imports the edited validator. The Wave 19 check returns `PASS` for the overlapping assemblies as demonstrated by the red control JSON, not merely inferred from reading its code.

### Reproduce (no native packages needed)

```bash
unzip lane15_bim_wave19_evidence.zip -d wave19
cd wave19
git apply ../wave20-local.patch
PYTHONPATH=baseline:. python -m unittest discover -s . -p 'test_*.py' -q
(cd baseline && PYTHONPATH=..:. python -m unittest discover -s . -p 'test_*.py' -q)
python wave20_topology_matrix.py
PYTHONPATH=baseline:. python runtime_gate.py \
  benchmarks/small_residence benchmarks/field_clinic benchmarks/workshop \
  --author-ifc --ifc-units both --report evidence/wave20-runtime-report.json
```

The standalone ZIP contains the full post-patch snapshot and `evidence/mesh_volume_gate_wave19.py` for reproducing both old/new matrix results:

```bash
python wave20_topology_matrix.py --gate evidence/mesh_volume_gate_wave19.py
python wave20_topology_matrix.py --gate mesh_volume_gate.py
```

Logs, machine-readable matrix results, full geometry runtime receipts and file hashes are included. A `git apply --check` and independent clean extraction/rerun passed.

## Controls, credit, and next decision

Read canonical factory [AGENTS](https://github.com/kvnloo/oss-factory/blob/main/AGENTS.md), [registry](https://github.com/kvnloo/oss-factory/blob/main/factory/projects.json), [control plane](https://github.com/kvnloo/oss-factory/blob/main/factory/CONTROL_PLANE.md) and [HITL](https://github.com/kvnloo/oss-factory/blob/main/factory/HITL.md), plus [IfcOpenShell AGENTS](https://github.com/IfcOpenShell/IfcOpenShell/blob/v0.9.0/AGENTS.md). `IfcOpenShell` is not yet on factory default-branch registry; [draft #100](https://github.com/kvnloo/oss-factory/pull/100) proposes a writable code fork and keeps existing coordination routing unchanged. **No global six-worker claim was taken or inferred.** Current upstream [PR #9295](https://github.com/IfcOpenShell/IfcOpenShell/pull/9295), authored by **BIMvoice** following [issue #9294](https://github.com/IfcOpenShell/IfcOpenShell/issues/9294), remains open (checked 2026-10-15); it concerns `IfcProjectLibrary` units, not this local mesh check. All new/altered code and artifact documentation here used AI assistance; no upstream authorship is claimed.

**Exact blocker:** `ifcopenshell` 0.9.0, Blender/Bonsai, `pxr`, `IfcConvert`, and `energyplus` are absent. Package index access from this sandbox failed DNS resolution; an attempted 0.9.0 wheel download did not succeed. Therefore the native IFC4 m/mm code path has **not executed**, the six IFC bodies' connectedness has **not been observed through an IFC kernel**, USD was parsed only by the separate static parser, and IDF remains a geometry fragment without the constructions/loads/weather necessary for energy simulation. Do not promote these synthetic results as origin defects.

**Next highest-value action:** On a pinned native runtime, author and reopen metre + millimetre IFC4 reference buildings, run the IfcOpenShell geometry kernel and six-shell/topology/volume parity checks, then inspect the resulting model in Bonsai. Only after geometry passes, test real OpenUSD parsing and EnergyPlus input parsing/thermal boundary mapping; finally add complete model inputs before claiming simulated kWh. This advances **Manufacturing → IFC → OpenUSD → EnergyPlus → Civilization** without invented measurements.
