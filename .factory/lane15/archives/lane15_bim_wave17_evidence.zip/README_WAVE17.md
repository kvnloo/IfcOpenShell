<!-- This document was generated with the assistance of an AI coding tool. -->
# Lane 15 · Wave 17 — USD orientation and transform integrity

**Status:** `LOCAL_ONLY` / `LIMITED`. No factory worker lease, hosted CI, upstream write, default-branch merge, or construction/energy outcome claim.

## Reproduced local defect

The constrained dependency-free USDA preflight previously accepted two classes
of physically meaningful scene changes without changing its interpreted six
polygons:

1. `uniform token orientation = "leftHanded"` on the roof mesh reverses
   the surface's front-facing interpretation while unchanged vertex ordering
   still appeared to satisfy our outward-normal contract.
2. USD scene `xformOp:translate` or `xformOp:scale` on the parent Building
   changes the effective world-space geometry, while the static parser
   incorrectly checked its untouched mesh-local points as world coordinates.

This is **our local validator error**, not an origin IfcOpenShell/OpenUSD defect.
The OpenUSD user guide explicitly documents both the orientation attribute
and transforms: https://openusd.org/dev/user_guides/schemas/usdGeom/overview.html .

## Fix

`wave17-local.patch` changes only the local `baseline/test_export_invariants.py`
and `runtime_gate.py`:

- Static preflight rejects any authored `xformOp:*` or `xformOpOrder` it does
  not evaluate. This rejects otherwise valid USD scenes intentionally, rather
  than claim support for transforms the parser does not understand.
- Static preflight rejects left-handed/malformed/duplicate mesh orientation,
  accepts default and explicit right-handed orientation.
- When the actual `pxr` runtime is available, the native OpenUSD probe also
  checks `UsdGeom.Mesh.GetOrientationAttr()` before accepting its world-space
  points as outward-facing geometry. **This branch is not native tested.**

## Measured verification (Python 3.13.5, local)

- Before fix: **3 negative subcases falsely accepted**: 1 left-handed roof,
  1 translated parent, 1 reflected parent (`wave17-red.log`).
- After fix: these negative subcases rejected; explicit `rightHanded` remains
  accepted (`wave17-focused-green.log`).
- Clean application against exact Wave 16 ZIP: **91 primary tests run (90 pass,
  1 native skip)** and **18 baseline tests pass** = **108 passed, 1 skipped**.
- Six? No: **three original positive fixture preflights pass**. Nine
  separate tampering cases (3 mutations × 3 fixtures) are **9/9 rejected**.
- `runtime_gate.py` on the same three fixtures: **3 analytic geometry PASS**,
  **zero Civilization capabilities verified**; all native IFC, native OpenUSD
  and EnergyPlus gates remain `NOT_RUN`.

The native IFC authoring route remains blocked: `ifcopenshell` unavailable to
Python 3.13.5 here (`pip install` returned no matching distribution for this
index); `pxr`, `IfcConvert`, Blender/Bonsai, and EnergyPlus are absent.
This patch does *not* establish real IFC4 round-trip, USD rendering/scene
composition, thermal/energy accuracy, weather, loads, or carbon impact.

## Reproduction

```sh
unzip lane15_bim_wave16_evidence.zip -d wave16
cd wave16
patch -p1 < ../wave17-local.patch
PYTHONPATH=baseline:. python -m unittest discover -s . -p 'test_*.py' -q
(cd baseline && python -m unittest discover -s . -p 'test_*.py' -q)
PYTHONPATH=baseline:. python runtime_gate.py \
  benchmarks/small_residence benchmarks/field_clinic benchmarks/workshop \
  --author-ifc --ifc-units both --report wave17-runtime-report.json
```

The ZIP is standalone for current local tests. `wave17-local.patch` can also
be applied to the existing Wave 16 archive without replacing the rest of it.

## Control plane / attribution

Inspected the current `kvnloo/oss-factory` `AGENTS.md`, `factory/CONTROL_PLANE.md`,
`factory/HITL.md`, and `factory/projects.json`, and IfcOpenShell `v0.9.0/AGENTS.md`.
The provisional IfcOpenShell registry registration is already under
[factory draft PR #100](https://github.com/kvnloo/oss-factory/pull/100), not in
canonical main, and [work item #104](https://github.com/kvnloo/oss-factory/issues/104)
is the existing deduplicated coordination thread. No new registration was
opened, no lease was claimed, and no external publication was attempted.

IfcOpenShell contribution convention: LGPL-3.0-or-later library,
GPL-3.0-or-later Bonsai, focused changes, disclose AI-generated code.
Existing upstream units fix: [IfcOpenShell #9295](https://github.com/IfcOpenShell/IfcOpenShell/pull/9295)
by **BIMvoice**, addressing upstream issue reports including **joepaddock-uk**;
not duplicated. All new local code/tests in this Wave 17 were written with AI
assistance. Existing fixtures/building geometry are inherited from prior
Lane 15 waves and are not represented as fresh measurements.

## Next high-value action

On a host with `ifcopenshell` and `pxr`, validate metre/mm IFC4 serialized
space boundaries, load actual USD transforms and handedness, inspect in Bonsai,
then construct a runnable EnergyPlus case with weather and constructions.
Keep `geometry_ready` separate from verified energy-model simulation output;
only then consider promoting to the Civilization capability graph.
