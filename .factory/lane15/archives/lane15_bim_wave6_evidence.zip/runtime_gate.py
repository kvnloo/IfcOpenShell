# This file was generated with the assistance of an AI coding tool.
"""Fail-closed IFC -> OpenUSD -> EnergyPlus -> Civilization evidence gate.

Wave 6 is a local prototype, not a proof of any real energy performance.
The existing geometry-only IDF fragment must never be called a load model.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent / "baseline"))

from test_export_invariants import Building, Surface, area as face_area, parse_idf, parse_usda, verify_cross_format, verify_shell
from test_crosswalk import crosswalk
from ifc_author import Dimensions, run as run_ifc


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def native_openusd_probe(path: Path, building: Building) -> dict:
    """Only real pxr stage parsing can return PASS, not the USDA regex parser."""
    try:
        from pxr import Gf, Usd, UsdGeom
    except ImportError:
        return {"status": "NOT_RUN", "reason": "pxr/OpenUSD Python runtime unavailable"}
    try:
        stage = Usd.Stage.Open(str(path))
        if stage is None:
            raise AssertionError("OpenUSD failed to open USDA stage")
        if not math.isclose(float(UsdGeom.GetStageMetersPerUnit(stage)), 1.0, abs_tol=1e-12):
            raise AssertionError("OpenUSD units are not metres")
        if str(UsdGeom.GetStageUpAxis(stage)) != "Z":
            raise AssertionError("OpenUSD is not Z-up")
        xforms = UsdGeom.XformCache()
        meshes = {}
        for name in ("Floor", "Roof", "South", "North", "East", "West"):
            prim = stage.GetPrimAtPath(f"/Building/{name}")
            if not prim or not prim.IsA(UsdGeom.Mesh):
                raise AssertionError(f"OpenUSD missing/non-mesh prim: {name}")
            mesh = UsdGeom.Mesh(prim)
            if list(mesh.GetFaceVertexCountsAttr().Get()) != [4]:
                raise AssertionError(f"OpenUSD wrong face topology: {name}")
            if list(mesh.GetFaceVertexIndicesAttr().Get()) != [0, 1, 2, 3]:
                raise AssertionError(f"OpenUSD wrong winding indices: {name}")
            transform = xforms.GetLocalToWorldTransform(prim)
            points = mesh.GetPointsAttr().Get()
            if points is None or len(points) != 4:
                raise AssertionError(f"OpenUSD wrong point count: {name}")
            transformed = tuple(tuple(float(c) for c in transform.Transform(Gf.Vec3d(*p))) for p in points)
            meshes[name] = Surface(name, "Floor" if name == "Floor" else "Roof" if name == "Roof" else "Wall", transformed)
        verified = verify_shell(meshes, building)
        return {"status": "PASS", "checked_faces": 6, "volume_m3": verified["enclosed_volume_m3"]}
    except Exception as exc:
        return {"status": "FAIL", "reason": str(exc)}


def check_case(directory: Path, allow_ifc_author: bool = False) -> dict:
    """Produce a deterministic, locally auditable per-building capability packet."""
    metrics_path = directory / "metrics.json"
    usda_path = directory / "single_zone.usda"
    idf_path = directory / "single_zone_geometry.idf"
    metrics = json.loads(metrics_path.read_text())
    xyz = metrics["dimensions_m"]
    building = Building(*(float(xyz[k]) for k in ("length", "width", "height")))
    dim = Dimensions(building.length_m, building.width_m, building.height_m)
    usd = parse_usda(usda_path)
    idf = parse_idf(idf_path)
    usd_result = verify_shell(usd, building)
    idf_result = verify_shell(idf, building)
    verify_cross_format(usd, idf)
    crosswalk(dim)
    volume = building.length_m * building.width_m * building.height_m
    area = 2 * (building.length_m * building.width_m + building.length_m * building.height_m
                + building.width_m * building.height_m)
    for actual in (metrics["nominal_volume_m3"], usd_result["enclosed_volume_m3"],
                   idf_result["enclosed_volume_m3"]):
        if not math.isclose(actual, volume, rel_tol=1e-9, abs_tol=1e-7):
            raise AssertionError("Cross-format volume mismatch")
    for actual in (metrics["envelope_area_m2"], usd_result["shell_area_m2"],
                   idf_result["shell_area_m2"]):
        if not math.isclose(actual, area, rel_tol=1e-9, abs_tol=1e-7):
            raise AssertionError("Cross-format area mismatch")
    if metrics["energy_demand_kwh"] is not None:
        raise AssertionError("Unverified energy demand inserted in geometry-only metrics")
    if set(metrics["face_areas_m2"]) != set(usd):
        raise AssertionError("Face-area ledger has missing/extra surfaces")
    for name, measured in metrics["face_areas_m2"].items():
        if not isinstance(measured, (int, float)) or not math.isclose(
            measured, face_area(usd[name]), rel_tol=1e-9, abs_tol=1e-7
        ):
            raise AssertionError(f"Face-area ledger mismatch: {name}")
    packet = {
        "building": directory.name,
        "dimensions_m": xyz,
        "sha256": {p.name: sha256(p) for p in (metrics_path, usda_path, idf_path)},
        "analytic_geometry": {"status": "PASS", "faces": 6,
                              "floor_area_m2": building.length_m * building.width_m,
                              "envelope_area_m2": area, "volume_m3": volume,
                              "evidence_level": "synthetic static-geometry only"},
        "real_openusd_stage": native_openusd_probe(usda_path, building),
        "ifc_authoring": {"status": "NOT_RUN", "reason": "Explicit opt-in required"},
        "bonsai_visual_inspection": {"status": "NOT_RUN", "reason": "Blender/Bonsai GUI not inspected"},
        "energyplus_simulation": {"status": "NOT_RUN", "reason": (
            "IDF is a geometry-only fragment with undefined constructions; "
            "needs real constructions, schedules and simulation inputs"),
            "energyplus_binary_present": bool(shutil.which("energyplus"))},
        "energy_demand_kwh": None,
        "license_scope": "AI-assisted local prototype; review licensing before promotion",
    }
    if allow_ifc_author:
        try:
            result = run_ifc(directory / "ifc_runtime", dim)
            state = result.get("runtime_checks", {}).get("geometry_kernel")
            packet["ifc_authoring"] = {"status": "PASS" if state == "PASS" else "NOT_RUN",
                                       "evidence": result}
        except Exception as exc:
            packet["ifc_authoring"] = {"status": "FAIL", "reason": str(exc)}
    required = ("ifc_authoring", "real_openusd_stage", "bonsai_visual_inspection", "energyplus_simulation")
    packet["civilization"] = {"verified_construction_capability": all(packet[k]["status"] == "PASS" for k in required),
                               "status": "UNVERIFIED", "route": "Manufacturing->IFC/Bonsai->OpenUSD->EnergyPlus->Civilization"}
    if packet["civilization"]["verified_construction_capability"]:
        packet["civilization"]["status"] = "VERIFIED"
    return packet


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("inputs", nargs="+", type=Path, help="Building fixture directories")
    parser.add_argument("--report", type=Path, required=True)
    parser.add_argument("--author-ifc", action="store_true", help="Attempt IfcOpenShell runtime authoring/geometry")
    args = parser.parse_args()
    packets = [check_case(p, args.author_ifc) for p in args.inputs]
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.report.write_text(json.dumps({"schema": "lane15-construction-preflight-v1", "cases": packets},
                                      indent=2) + "\n")
    print(f"{len(packets)} geometry preflights passed; "
          f"{sum(p['civilization']['verified_construction_capability'] for p in packets)} verified capabilities")
    if any(any(p[gate]["status"] == "FAIL" for gate in
               ("real_openusd_stage", "ifc_authoring", "energyplus_simulation")) for p in packets):
        raise SystemExit(1)


if __name__ == "__main__":
    main()
