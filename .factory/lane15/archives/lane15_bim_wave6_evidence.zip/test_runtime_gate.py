# This file was generated with the assistance of an AI coding tool.
"""Negative controls for fail-closed construction capability reporting."""
import json
import sys
import unittest
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent / "baseline"))
from export_surfaces import export
from runtime_gate import check_case, native_openusd_probe
from test_export_invariants import Building


class RuntimeGateTests(unittest.TestCase):
    def setUp(self):
        self.tmp = TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.folder = Path(self.tmp.name) / "residence"
        export(self.folder, 6, 8, 2.7)

    def test_real_files_have_static_pass_and_capability_unverified(self):
        report = check_case(self.folder)
        self.assertEqual(report['analytic_geometry']['status'], 'PASS')
        self.assertFalse(report['civilization']['verified_construction_capability'])
        self.assertIsNone(report['energy_demand_kwh'])
        self.assertEqual(report['energyplus_simulation']['status'], 'NOT_RUN')
        self.assertEqual(len(report['sha256']), 3)

    def test_disabled_ifc_author_is_not_a_pass(self):
        report = check_case(self.folder)
        self.assertEqual(report['ifc_authoring']['status'], 'NOT_RUN')

    def test_report_rejects_injected_energy_claim(self):
        p = self.folder / 'metrics.json'
        data = json.loads(p.read_text())
        data['energy_demand_kwh'] = 12.5
        p.write_text(json.dumps(data))
        with self.assertRaisesRegex(AssertionError, 'energy'):
            check_case(self.folder)

    def test_report_rejects_tampered_single_face_area(self):
        p = self.folder / 'metrics.json'
        data = json.loads(p.read_text())
        data['face_areas_m2']['South'] += 1
        p.write_text(json.dumps(data))
        with self.assertRaisesRegex(AssertionError, 'Face-area'):
            check_case(self.folder)

    def test_runtime_failure_cannot_verify_capability(self):
        with patch('runtime_gate.native_openusd_probe', return_value={'status': 'FAIL', 'reason': 'bad USD'}):
            report = check_case(self.folder)
        self.assertEqual(report['real_openusd_stage']['status'], 'FAIL')
        self.assertFalse(report['civilization']['verified_construction_capability'])

    def test_report_rejects_tampered_floor_area(self):
        p = self.folder / 'metrics.json'
        data = json.loads(p.read_text())
        data['envelope_area_m2'] = 200.0
        p.write_text(json.dumps(data))
        with self.assertRaisesRegex(AssertionError, 'area'):
            check_case(self.folder)

    def test_report_rejects_usd_unit_mutation(self):
        p = self.folder / 'single_zone.usda'
        p.write_text(p.read_text().replace('metersPerUnit = 1', 'metersPerUnit = 0.001'))
        with self.assertRaisesRegex(AssertionError, 'unit'):
            check_case(self.folder)

    def test_report_rejects_idf_coordinate_mutation(self):
        p = self.folder / 'single_zone_geometry.idf'
        p.write_text(p.read_text().replace('6.000000', '6000.000000', 1))
        with self.assertRaises(AssertionError):
            check_case(self.folder)

    def test_report_rejects_missing_geometry_file(self):
        (self.folder / 'single_zone.usda').unlink()
        with self.assertRaises(FileNotFoundError):
            check_case(self.folder)

    def test_px_runtime_missing_is_explicit(self):
        with patch.dict('sys.modules', {'pxr': None}):
            result = native_openusd_probe(self.folder / 'single_zone.usda', Building(6, 8, 2.7))
        self.assertEqual(result['status'], 'NOT_RUN')

    def test_ifc_opt_in_reports_missing_wheel(self):
        with patch.dict('sys.modules', {'ifcopenshell': None}):
            result = check_case(self.folder, allow_ifc_author=True)
        self.assertEqual(result['ifc_authoring']['status'], 'NOT_RUN')
        self.assertFalse(result['civilization']['verified_construction_capability'])


if __name__ == '__main__':
    unittest.main()
