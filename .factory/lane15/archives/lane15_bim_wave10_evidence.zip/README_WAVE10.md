# Lane 15 / Wave 10 — IFC4 space boundary level guard (LOCAL_ONLY)

Generated with assistance from an AI coding tool. No origin writes, claim leases, or publication authorization.

## Problem and change

The prior synthetic IFC author created generic `IfcRelSpaceBoundary` relations while its results described first-level boundaries. The IFC4 schema exposes `IfcRelSpaceBoundary1stLevel` for an unsplit architectural space boundary; a second-level boundary is a distinct thermal decomposition. This patch instantiates the explicit first-level subtype and makes both the topology audit and saved-geometry verifier fail closed if a generic or second-level relation is substituted. Second-level thermo-physical handling and energy-demand claims remain out of scope.

The API contract was read at current upstream source (IfcOpenShell contributors; `api/boundary/{assign_connection_geometry,edit_attributes}.py`; `api/root/create_entity.py`) and IFC4 schema references. This is local fixture hardening only, **not** a claim that current upstream behavior is defective. The unit detection PR #9295 by BIMvoice remains independent.

## Repro

```sh
python -m unittest discover -s . -p 'test_*.py' -v
(cd baseline && python -m unittest discover -s . -p 'test_*.py' -v)
python runtime_gate.py benchmarks/small_residence benchmarks/field_clinic benchmarks/workshop --report wave10-runtime-report.json --author-ifc
```

Result: 70/70 local tests + 10/10 baseline tests PASS; three analytic fixtures PASS. Native IFC, Bonsai, OpenUSD and EnergyPlus are NOT_RUN because the executables/imports are unavailable in this sandbox. No `.ifc` or simulated energy load was produced, and zero Civilization construction capabilities are verified. This remains a local, AI-assisted prototype. Before any eventual origin contribution, ensure compatibility with LGPL-3.0-or-later for library code, GPL-3.0-or-later for Bonsai code, AI disclosure, and focused changes.

## Factory

Read the current `kvnloo/oss-factory` AGENTS.md, CONTROL_PLANE.md, HITL.md and registry. `ifcopenshell` is not merged to registry; #100 remains draft, #104 is coordination-only. No global lease and no origin authorization inferred. No GitHub writes.

## Next

On a runtime with `ifcopenshell==0.9.0` (or pinned compatible version): generate IFC4; reopen and EXPRESS-validate; inspect first-level relationship entities, `IfcCurveBoundedPlane`, scale and geometry-kernel bounds; inspect in Bonsai. Separately verify USD through pxr and a *complete* EnergyPlus input with construction and weather. Preserve the explicit 1st-vs-2nd-level distinction and never promote synthetic energy metrics as measured loads.
