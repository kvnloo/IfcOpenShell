# Lane 15 · Wave 6: fail-closed interoperability evidence

AI-assisted local prototype. Not a verified IFC, Bonsai, OpenUSD or EnergyPlus runtime pipeline; not an energy model. No GitHub writes, worker claims, lease creation or origin promotion were performed.

## What is new

`runtime_gate.py` audits real generated files for per-face geometry/area, nominal volume, surface normals, IFC-analytic interior-face alignment and explicit unit metadata, and records SHA-256 hashes. It can *optionally* author and verify an IFC4 file using the existing Wave 5 `ifc_author.py`, and actually opens the USDA stage with the `pxr` API when available. The gate **never** substitutes static regex parsing for a runtime PASS.

`test_runtime_gate.py` adds 11 deterministic regression checks, including corrupted units, per-face quantities, envelope area, coordinates, missing files, invented energy demand, absent runtime dependencies and explicit runtime failure. A generated capability packet marks Civilizaton `UNVERIFIED` until actual IFC geometry-kernel, OpenUSD stage, Bonsai inspection and EnergyPlus simulation evidence exist.

## Observed results (this sandbox)

- **42/42 tests pass**: 32 integrated local tests + 10 exporter baseline tests.
- Three geometry-only fixtures: residence 6×8×2.7 m (129.6 m³), clinic 18×12×3.6 m (777.6 m³), workshop 30×20×7 m (4200 m³).
- **IFC runtime: NOT_RUN** (IfcOpenShell package absent; pip index DNS lookup unavailable).
- **OpenUSD runtime: NOT_RUN** (`pxr` absent).
- **Bonsai: NOT_RUN**, **EnergyPlus: NOT_RUN** (geometry fragment has unresolved constructions; no load model or validated weather/schedules).
- **Civilization verified construction capabilities: 0**. No fabricated energy-use values.

## Reproduce

```sh
OPENBLAS_NUM_THREADS=1 python -m unittest -v test_runtime_gate test_parametric_export test_ifc_author test_crosswalk
(cd baseline && OPENBLAS_NUM_THREADS=1 python -m unittest discover -s . -p 'test_*.py' -v)
OPENBLAS_NUM_THREADS=1 python runtime_gate.py benchmarks/small_residence benchmarks/field_clinic benchmarks/workshop --report wave6-runtime-report.json --author-ifc
```

To obtain runtime evidence, repeat with a compatible IfcOpenShell Python wheel (`ifcopenshell`), OpenUSD `pxr` bindings and separately a Bonsai-capable Blender runtime. Build valid constructions, schedules and climate inputs before executing and asserting EnergyPlus results; the current IDF file is **not runnable as a load model**. The CLI exits with an error for real runtime FAIL and deliberately leaves missing runtimes as NOT_RUN.

## Provenance and upstream gates

- Factory control: `kvnloo/oss-factory` `AGENTS.md`, `factory/projects.json`, `factory/CONTROL_PLANE.md`, `factory/HITL.md`, fetched October 15 UTC. Canonical main registry does not yet have an IfcOpenShell entry; factory draft PR #100 proposes one. `energyplus` is tracked only as watch-state.
- Coordination: https://github.com/kvnloo/oss-factory/issues/104; upstream #9295 is BIMvoice's preexisting scale fix (https://github.com/IfcOpenShell/IfcOpenShell/pull/9295), do not duplicate. Credit original reporters too.
- IfcOpenShell `v0.9.0/AGENTS.md`: new AI files marked; library LGPL-3.0-or-later, Bonsai GPL-3.0-or-later. Local tools remain unpromoted pending review of applicable licensing, project requirement and authorized HITL.
- Source lineage: Wave 5 synthetic fixtures and tests; this wave only adds `runtime_gate.py`, `test_runtime_gate.py` and evidence.
- No origin code, third-party dataset, user-sensitive information or secret included.

## Next priority

Run the first generated `.ifc` through actual IfcOpenShell kernel and validate bounds/scale against the USDA and IDF geometry, then manually inspect in Bonsai. After native OpenUSD parsing, build a fully specified EnergyPlus *test model*, distinguish design day from weather-driven annual loads, and retain versions, input hash and logs. Do not credit a Civilization capability before every required runtime check passes.
