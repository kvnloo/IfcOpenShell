# This file was generated with the assistance of an AI coding tool.
"""Independent exported-surface contract for Lane 15's synthetic fixture.

Scope: parse the deliberately small, emitted USDA/IDF grammar. This is not
USD or EnergyPlus parser validation, IFC validation, or an energy simulation.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import math
from pathlib import Path
import random
import re
from tempfile import TemporaryDirectory
import unittest

from export_surfaces import export
from single_zone_contract import shell as reference_shell

Point = tuple[float, float, float]


@dataclass(frozen=True)
class Building:
    length_m: float = 10.0
    width_m: float = 8.0
    height_m: float = 3.0

@dataclass(frozen=True)
class Surface:
    name: str
    kind: str
    vertices: tuple[Point, ...]


def diff(a, b):
    return tuple(x - y for x, y in zip(a, b))


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def area_vector(s):
    p, q, r, t = s.vertices
    av1 = cross(diff(q, p), diff(r, p))
    av2 = cross(diff(r, p), diff(t, p))
    return tuple((x + y) / 2 for x, y in zip(av1, av2))


def area(s):
    return math.sqrt(sum(x * x for x in area_vector(s)))

def signed_enclosed_volume(surfaces):
    result = 0
    for s in surfaces:
        c = tuple(sum(v[i] for v in s.vertices) / 4 for i in range(3))
        result += sum(x * y for x, y in zip(area_vector(s), c)) / 3
    return result

def build(path):
    export(path)


def parse_usda(path: Path) -> dict[str, Surface]:
    data = path.read_text(encoding="utf-8")
    if '#usda 1.0' not in data or 'upAxis = "Z"' not in data or 'metersPerUnit = 1' not in data:
        raise AssertionError("USDA unit, axis or header mismatch")
    pattern = re.compile(r'def Mesh "([^"\n]+)"\s*\{([^{}]+)\}', re.MULTILINE)
    result: dict[str, Surface] = {}
    for name, block in pattern.findall(data):
        if 'faceVertexCounts = [4]' not in block or 'faceVertexIndices = [0, 1, 2, 3]' not in block:
            raise AssertionError(f"Wrong mesh topology for {name}")
        raw = re.search(r'point3f\[\] points = \[([^\]]+)\]', block)
        if raw is None:
            raise AssertionError(f"No points for {name}")
        vertices = [
            tuple(float(x.strip()) for x in group.split(','))
            for group in re.findall(r'\(([^()]+)\)', raw.group(1))
        ]
        if len(vertices) != 4 or any(len(p) != 3 for p in vertices):
            raise AssertionError(f"Wrong face arity for {name}")
        if name in result:
            raise AssertionError(f"Duplicate USDA mesh {name}")
        result[name] = Surface(name, "Floor" if name == "Floor" else "Roof" if name == "Roof" else "Wall",
                               tuple(vertices))
    if len(result) != 6:
        raise AssertionError(f"Expected six USDA meshes, got {len(result)}")
    return result


def parse_idf(path: Path) -> dict[str, Surface]:
    data = "\n".join(line.split("!", 1)[0] for line in path.read_text(encoding="utf-8").splitlines())
    commands = [obj.strip() for obj in data.split(";") if obj.strip()]
    geometry_rule = r'GlobalGeometryRules\s*,\s*UpperLeftCorner\s*,\s*CounterClockWise\s*,\s*World'
    if not any(re.match(geometry_rule, obj) for obj in commands):
        raise AssertionError("EnergyPlus world-coordinate vertex convention not specified")
    result: dict[str, Surface] = {}
    for obj in commands:
        tokens = [x.strip() for x in obj.split(",")]
        if tokens[0] != "BuildingSurface:Detailed":
            continue
        if len(tokens) != 23 or tokens[10] != "4":
            raise AssertionError("Invalid EnergyPlus surface field count or vertex count")
        name, kind, construction, zone, boundary, other_zone, sun, wind, view_factor, numvertices = tokens[1:11]
        if zone != "TestZone" or not construction.endswith("Placeholder"):
            raise AssertionError("Unexpected zone or missing unresolved-construction flag")
        if kind == "Floor":
            if boundary != "Ground" or sun != "NoSun" or wind != "NoWind":
                raise AssertionError("Invalid floor boundary conditions")
        elif boundary != "Outdoors" or sun != "SunExposed" or wind != "WindExposed":
            raise AssertionError("Invalid wall/roof boundary conditions")
        vertices = tuple(tuple(float(tokens[11 + i * 3 + j]) for j in range(3)) for i in range(4))
        if name in result:
            raise AssertionError("Duplicate IDF surface")
        result[name] = Surface(name, kind, vertices)
    if len(result) != 6:
        raise AssertionError(f"Expected six IDF surfaces, got {len(result)}")
    return result


def verify_shell(surfaces: dict[str, Surface], b: Building, atol: float = 2e-5) -> dict[str, float]:
    """Independently verify topology, outward orientation, area and volume."""
    expected = {
        "Floor": ((0, 0, -1), b.length_m * b.width_m),
        "Roof": ((0, 0, +1), b.length_m * b.width_m),
        "South": ((0, -1, 0), b.length_m * b.height_m),
        "North": ((0, +1, 0), b.length_m * b.height_m),
        "East": ((+1, 0, 0), b.width_m * b.height_m),
        "West": ((-1, 0, 0), b.width_m * b.height_m),
    }
    if set(surfaces) != set(expected):
        raise AssertionError("Missing or extra surface")
    edge_use: Counter[tuple[Point, Point]] = Counter()
    directed: Counter[tuple[Point, Point]] = Counter()
    for name, s in surfaces.items():
        normal, surface_area = expected[name]
        av = area_vector(s)
        if not math.isclose(area(s), surface_area, rel_tol=0, abs_tol=atol):
            raise AssertionError(f"Area mismatch: {name}")
        if any(not math.isclose(av[i], normal[i] * surface_area, rel_tol=0, abs_tol=atol) for i in range(3)):
            raise AssertionError(f"Normal mismatch: {name}")
        for a, c in zip(s.vertices, s.vertices[1:] + s.vertices[:1]):
            edge_use[tuple(sorted((a, c)))] += 1
            directed[(a, c)] += 1
    if len(edge_use) != 12 or any(count != 2 for count in edge_use.values()):
        raise AssertionError("Open, non-manifold, or disconnected shell")
    if any(directed[(a, c)] != directed[(c, a)] for a, c in edge_use):
        raise AssertionError("Inconsistent paired edge direction")
    volume = signed_enclosed_volume(tuple(surfaces.values()))
    expected_volume = b.length_m * b.width_m * b.height_m
    if not math.isclose(volume, expected_volume, rel_tol=0, abs_tol=atol):
        raise AssertionError(f"Volume mismatch: {volume} vs {expected_volume}")
    return {"enclosed_volume_m3": volume, "shell_area_m2": sum(area(s) for s in surfaces.values()),
            "closed_undirected_edges": len(edge_use)}


def verify_cross_format(usd: dict[str, Surface], ep: dict[str, Surface], atol: float = 1e-6) -> None:
    if usd.keys() != ep.keys():
        raise AssertionError("Format face set mismatch")
    for name in usd:
        if usd[name].kind != ep[name].kind:
            raise AssertionError(f"Surface category mismatch: {name}")
        # A cyclic shift keeps the same outward-oriented face, unlike reversal.
        uverts, everts = usd[name].vertices, ep[name].vertices
        matches = any(
            all(all(abs(uverts[i][axis] - everts[(i + shift) % 4][axis]) <= atol
                    for axis in range(3)) for i in range(4))
            for shift in range(4)
        )
        if not matches:
            raise AssertionError(f"USDA/IDF geometry or winding mismatch at {name}")


class ExportRoundTrip(unittest.TestCase):
    def test_parse_both_exports(self):
        with TemporaryDirectory() as tmp:
            out = Path(tmp)
            b = Building()
            build(out)
            u = parse_usda(out / "single_zone.usda")
            e = parse_idf(out / "single_zone_geometry.idf")
            self.assertEqual(verify_shell(u, b)["closed_undirected_edges"], 12)
            self.assertEqual(verify_shell(e, b)["enclosed_volume_m3"], 240.0)
            verify_cross_format(u, e)

    def test_100_parameterized_reference_shells(self):
        rand = random.Random(15015)
        for i in range(100):
            b = Building(round(rand.uniform(4, 25), 3), round(rand.uniform(4, 25), 3),
                         round(rand.uniform(2.1, 8), 3))
            faces = reference_shell(b.length_m, b.width_m, b.height_m)
            surfaces = {
                name: Surface(name, "Floor" if name == "Floor" else "Roof" if name == "Roof" else "Wall", points)
                for name, points in faces.items()
            }
            with self.subTest(i=i):
                verify_shell(surfaces, b, atol=1e-4)

    def test_detect_usda_winding_corruption(self):
        with TemporaryDirectory() as tmp:
            out = Path(tmp)
            build(out)
            src = out / "single_zone.usda"
            text = src.read_text()
            text = text.replace('faceVertexIndices = [0, 1, 2, 3]', 'faceVertexIndices = [0, 3, 2, 1]', 1)
            src.write_text(text)
            with self.assertRaises(AssertionError):
                parse_usda(src)

    def test_detect_idf_coordinate_drift(self):
        with TemporaryDirectory() as tmp:
            out = Path(tmp)
            build(out)
            ep = parse_idf(out / "single_zone_geometry.idf")
            usd = parse_usda(out / "single_zone.usda")
            original = ep["Roof"]
            vertices = list(original.vertices)
            vertices[0] = (vertices[0][0], vertices[0][1], vertices[0][2] + 0.25)
            ep["Roof"] = Surface(original.name, original.kind, tuple(vertices))
            with self.assertRaises(AssertionError):
                verify_cross_format(usd, ep)
            with self.assertRaises(AssertionError):
                verify_shell(ep, Building())

    def test_detect_boundary_condition_drift(self):
        with TemporaryDirectory() as tmp:
            out = Path(tmp)
            build(out)
            path = out / "single_zone_geometry.idf"
            path.write_text(path.read_text().replace('Ground,', 'Outdoors,', 1))
            with self.assertRaises(AssertionError):
                parse_idf(path)


if __name__ == "__main__":
    unittest.main()
