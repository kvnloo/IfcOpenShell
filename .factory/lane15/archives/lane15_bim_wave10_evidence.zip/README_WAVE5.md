# Lane 15 · Wave 5 — Parameterized building geometry (LOCAL ONLY)

AI-assisted derivative of the Wave 4 synthetic one-zone reference. Not published to any repository.

## New outcome

The same USDA + EnergyPlus IDF fragment exporter now takes `--length`, `--width`, `--height` in metres. Previous defaults remain 10 × 8 × 3 m. Invalid non-finite or non-positive dimensions fail before files are written.

Independent, deliberately limited parsers and the physical-IFC analytical crosswalk verified actual generated files for **three representative synthetic building dimensions**. They are not real building BIM designs and are not energy simulations.

| Scenario | Dimensions, m | Floor, m² | Shell, m² | Volume, m³ |
|---|---:|---:|---:|---:|
| Residence | 6 × 8 × 2.7 | 48 | 171.6 | 129.6 |
| Field clinic | 18 × 12 × 3.6 | 216 | 648 | 777.6 |
| Workshop | 30 × 20 × 7 | 600 | 1900 | 4200 |

**31/31 `unittest` tests pass**: 21 new+retained Wave 4 tests, plus 10 unchanged earlier exporter tests. Physical IFC placements are analytical only; there was no IFC authoring, Bonsai check, OpenUSD runtime parser or EnergyPlus run. The IDF contains placeholder constructions and must not be used as a load model.

## Reproduction

```sh
python -m unittest -v test_parametric_export test_ifc_author test_crosswalk
(cd baseline && python -m unittest discover -s . -p 'test_*.py' -v)
python baseline/export_surfaces.py --out /tmp/clinic --length 18 --width 12 --height 3.6
```

The patch is `parametric_export.patch` and can be applied to the branch's `factory/evidence/lane15/export_surfaces.py`. It has **not** been pushed. The factory registry is still unmerged at draft PR #100. Issue #104 is the existing coordination surface. No claim or origin authorization.

## Next

Get an environment with an IfcOpenShell wheel and render/validate physical solids, then compare their interior faces to all three authored USDA/IDF fragments. Link actual EnergyPlus weather and material definitions before calculating any loads. Use BIMvoice's existing upstream unit-scale PR #9295 instead of a duplicate fix.

## Licenses and credit

If material is ever proposed upstream, comply with IfcOpenShell `AGENTS.md` AI disclosure and applicable LGPL-3.0-or-later library / GPL-3.0-or-later Bonsai rules. Existing project APIs and the authored Wave 4 files were the starting point. This wave does not claim the work of other contributors.
