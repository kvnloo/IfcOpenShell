# Lane 15 · Wave 8 — IFC→energy semantic handoff preflight (LOCAL_ONLY)

AI-assisted downstream experiment. **Not a production IFC authoring change, EnergyPlus result, Bonsai inspection, or upstream proposal.** Provenance: factory work order `kvnloo/oss-factory#104`, draft registration `kvnloo/oss-factory#100`, and Lane 15 Waves 1–7; upstream API and licensing from `IfcOpenShell/IfcOpenShell` contributors.

## Behavior and gap

The existing `ifc_author.py` creates a project/site/building/storey/space and four walls plus two slabs, but **does not author any `IfcRelSpaceBoundary` relationships**. This is confirmed by inspection of the source, **not** by running its IFC writer. Consequently, the geometry-only IDF exported in this prototype has no demonstrated IFC semantic zone-to-envelope mapping. Those six IDF surfaces are instead built from the independent synthetic thermal shell. That is appropriate for a static preflight, but not evidence of IFC→BEM interoperability.

## New executable prerequisite

`energy_handoff_gate.py` audits a real reopened IfcOpenShell model, if available. It requires one `IfcSpace` called `TestZone`, one `IfcRelSpaceBoundary` per wall/slab name, `PHYSICAL` boundaries, expected external/earth classification, and nonempty `ConnectionGeometry`. Its isolated `evaluate` function supports mock/model-free positive and mutation tests. All successful results are **`TOPOLOGY_READY_ONLY`**, not full boundary geometry verification or a load simulation.

Integrated with `ifc_author.py` and `runtime_gate.py`: authoring success cannot silently imply validated thermal-space linkage; a new `ifc_energy_boundary_handoff` field stays `NOT_RUN` when IFC dependencies are absent. Civilization capability stays false even under mock positive semantic topology alone.

## Reproduction

```bash
OPENBLAS_NUM_THREADS=1 python -m unittest discover -s . -p 'test_*.py' -v
(cd baseline && OPENBLAS_NUM_THREADS=1 python -m unittest discover -s . -p 'test_*.py' -v)
python -m py_compile energy_handoff_gate.py test_energy_handoff_gate.py ifc_author.py runtime_gate.py
python runtime_gate.py benchmarks/small_residence benchmarks/field_clinic benchmarks/workshop \
  --report wave8-runtime-report.json --author-ifc
```

**Observed 2026-10-15:** 56 current tests + 10 baseline = **66/66 PASS** on this runner. All three static building geometry fixtures pass; IFC authoring, actual OpenUSD parsing, Bonsai visual inspection, and EnergyPlus simulation remain `NOT_RUN`. Zero verified construction capabilities. The IfcOpenShell package install attempt failed because the package index's DNS name could not be resolved. No `.ifc` runtime artifact was generated.

## Next requirement evidence

The gate is a **Lane 15 energy handoff requirement**, **not** an established IfcOpenShell-wide requirement. Some valid BIM exports omit energy-space boundaries and derive them in the BEM converter. Before any origin proposal, confirm the expected BIM→BEM workflow with independent real samples or an existing maintainer contract. Material semantics, surface polygon agreement, complete EnergyPlus constructions, weather, and engine runs are all missing.

Next bounded work: run IfcOpenShell >=0.9.0 on a real installation, author and reopen the fixture, first record the expected missing space-boundary report, then author six supported IFC4 `IfcRelSpaceBoundary` connections and compare their `ConnectionGeometry` against the existing thermal shell. Inspect in Bonsai before attempting a physical construction / EnergyPlus model.

## Governance and credit

Read `kvnloo/oss-factory` AGENTS.md, `factory/projects.json`, `factory/CONTROL_PLANE.md`, and `factory/HITL.md`. On 2026-10-15, IfcOpenShell is **not** on the default-branch registry; registration is draft `#100`; coordinating work order is `#104`. No worker claim, no default-branch merge, no GitHub writes and no maintainer contact. Upstream unit-scale bug remains BIMvoice's **PR #9295**, with credit to its issue reporters. `IfcOpenShell` library contributions use LGPL-3.0-or-later; Bonsai uses GPL-3.0-or-later, and both require AI disclosure under `AGENTS.md`. This archive consists of local derivative experiment code, not a licensed upstream submission.
