# Lane 15 — Wave 9 (LOCAL_ONLY)

Generated with assistance from an AI coding tool. No upstream publication, worker lease, or origin authorization is implied.

## Concrete improvement

The previous experiment authored a physical IFC shell but **zero IFC space-boundary relationships**. This wave changes `ifc_author.py` to create six IFC4 `IfcRelSpaceBoundary` entities, associate each with `TestZone` and the correct physical wall/slab, and attach `IfcConnectionSurfaceGeometry` using IfcOpenShell's supported `api.boundary.assign_connection_geometry()` entry point. `boundary_geometry.py` constructs six outward-oriented planes and, on native execution, verifies reloaded IFC4 plane loops against the reference thermal boundary. The thermal surface remains distinct from wall/slab material solids.

The IFC API contract was checked against `IfcOpenShell/IfcOpenShell@v0.9.0` sources:

- `src/ifcopenshell-python/ifcopenshell/api/boundary/assign_connection_geometry.py` (copyright IfcOpenShell contributors, Dion Moult)
- `src/ifcopenshell-python/ifcopenshell/api/boundary/edit_attributes.py` (copyright IfcOpenShell contributors, Dion Moult)

`IfcAxis2Placement3D.Axis` is the plane normal (local Z); `RefDirection` is local X. Upstream `assign_connection_geometry` prose inadvertently reverses those axis labels. This wave uses the implemented IFC axis ordering and independently verifies the resulting reference coordinate frame; it does **not** propose an upstream documentation change.

Existing open upstream space-boundary project direction: `IfcOpenShell/IfcOpenShell#1676` (energy-model-auditing test coverage), `#2621` (geometry creation), `#3446` (update boundaries). This experiment is downstream evidence, not a duplicate upstream issue or fix. The existing `IfcProjectLibrary` unit-scale patch is BIMvoice's `#9295`, originating from `#9294` and affected real-user reports; no duplicate fix was attempted.

## Verification

From the extracted folder:

```bash
python -m unittest discover -s . -p 'test_*.py' -v
(cd baseline && python -m unittest discover -s . -p 'test_*.py' -v)
python -m py_compile ifc_author.py boundary_geometry.py test_boundary_geometry.py
python runtime_gate.py benchmarks/small_residence benchmarks/field_clinic benchmarks/workshop --report wave9-runtime-report.json --author-ifc
```

2026-10-15 results: **67/67 current tests pass, 10/10 baseline tests pass**, including 11 new boundary-frame/IFC-entity-mock controls. Three existing building fixture preflights pass. No native `.ifc` was produced here. Actual IFC authoring, save/reload, EXPRESS validation, IfcOpenShell C++ geometry-kernel verification, Bonsai visual inspection, OpenUSD parsing, and EnergyPlus simulation are **NOT_RUN**; therefore **zero verified Civilization construction capabilities**. The `ifcopenshell==0.9.0` wheel attempt failed on DNS/name-resolution, not on package compatibility.

Test provenance: isolated pure-Python code and mocked IFC entities. These results do **not** demonstrate the native IfcOpenShell API succeeds or an IFC→EnergyPlus load simulation, and do not establish upstream requirement impact.

## Factory controls

Read `kvnloo/oss-factory/AGENTS.md`, `factory/CONTROL_PLANE.md`, `factory/HITL.md`, `factory/projects.json`; registry does not yet contain `ifcopenshell` (draft `kvnloo/oss-factory#100`), and the existing handoff is `#104`. No claim against the six-worker pool was acquired, no GitHub/Linear writes or origin contacts occurred. Local prototype only. Compatible licensing and AI-assisted contribution disclosure need to be checked before any eventual origin proposal: IfcOpenShell library LGPL-3.0-or-later; Bonsai GPL-3.0-or-later.

## Next executable gate

On a native IfcOpenShell 0.9.0 or compatible worker, run the existing CLI with `--author-ifc`. Resolve any native exceptions, verify the *saved and reopened* six connection planes and solids, and compare the returned bounding/area report to USDA/IDF. Then separately load stage through `pxr.Usd` and a **completed** EnergyPlus model with valid constructions/schedules/weather. Never infer energy demand from the geometry-only fragment.
