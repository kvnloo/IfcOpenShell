# Lane 15 / Wave 4 — IFC4 solids ↔ zone-shell crosswalk (LOCAL ONLY)

AI-assisted downstream prototype; **not an upstream change, IFC runtime test, or energy-model verification**.

## Result (2026-10-15)

- 15 new Python `unittest` cases **PASS**. Includes 100 deterministic geometry parameterizations, six physical/thermal face crosswalks, and negative controls for shifted walls and slab direction.
- 10 existing wave-3 contract/export tests **PASS** (rechecked in this runtime).
- A six-solid **IfcOpenShell API authoring script** is prepared but **not executed**: no IfcOpenShell module, geometry kernel, Bonsai, USD runtime or EnergyPlus binary is installed here. `runtime-out/ifc_report.json` accurately labels every runtime check `NOT_RUN`.
- The nominal zone is 10 × 8 × 3 m; the analytic zone metrics remain **80 m² floor, 268 m² shell, 240 m³ volume**. These are reference inputs, not simulated results.
- The physical solids use 0.2 m walls and 0.2 m slabs **outside** the thermal reference shell, so the IFC building is not mistakenly represented as a zero-thickness energy zone. Physical bounding envelope is `[-0.2,-0.2,-0.2]` to `[10.2,8.2,3.2]` metres.
- IFC4 authoring intentionally defines one site, building, storey and space, four `IfcWall` solids, two `IfcSlab` solids, body representations and explicit metre units. **No material layers, energy materials, `IfcRelSpaceBoundary`, weather, HVAC, schedules, or energy consumption are implied.**

## Commands

```bash
python -m unittest -v test_ifc_author test_crosswalk
(cd baseline && python -m unittest discover -s . -p 'test_*.py' -v)
python ifc_author.py --output runtime-out
```

The last command emits a **blocked** report rather than fabricating an IFC if `ifcopenshell` is missing. On a supported machine with IfcOpenShell and NumPy, it will attempt IFC4 save, reopen, population validation and geometry kernel bounds. A passing runtime on this machine has **not** been observed.

## Required runtime gates

1. Install a supported IfcOpenShell build (API reference consulted: 0.9.1). Run the author and validate the saved/reopened IFC4 model with its geometry kernel. Capture package/platform/build versions and IFC SHA256.
2. Check units, product counts, nesting, physical bounds and `IfcRelSpaceBoundary` requirements; visually review in Bonsai.
3. Load USDA from wave 3 through actual OpenUSD; validate metre scale and Z-up independently.
4. Parse the geometry-only IDF fragment through EnergyPlus, then add materials, schedules, weather and correct thermal boundaries before any energy simulation or Civ achievement.
5. Reconcile existing factory draft PR 100 before registry changes; obtain six-worker capacity and Linear origin authorization before upstream action.

## Provenance / deduplication

- Existing geometry/IDF baseline: Lane 15 waves 1–3; unchanged files copied under `baseline/` for direct testing.
- IFC API design adapted from project docs, including `src/pyodide/demo-app/context.py`; these upstream patterns belong to IfcOpenShell contributors. No source code was copied into this experimental script.
- The unit-scale issue is already tracked under upstream issues #9294 / #9926 and **BIMvoice's PR #9295**. Do not duplicate.
- Factory registry remains pending [draft PR #100](https://github.com/kvnloo/oss-factory/pull/100); coordination issue [#104](https://github.com/kvnloo/oss-factory/issues/104) is canonical. No claims, external writes, merges, or public comments made this wave.
- Upstream AGENTS.md: LGPL-3.0-or-later for the library, GPL-3.0-or-later for Bonsai; explicit AI disclosure required.

Documentation:
- https://docs.ifcopenshell.org/autoapi/ifcopenshell/api/project/create_file/index.html
- https://docs.ifcopenshell.org/ifcopenshell-python/code_examples.html
- https://docs.ifcopenshell.org/autoapi/ifcopenshell/api/geometry/index.html
- https://docs.ifcopenshell.org/autoapi/ifcopenshell/validate/index.html
- https://bigladdersoftware.com/epx/docs/25-2/engineering-reference/shading-module.html

All generated code is explicitly marked as AI-assisted. 2026-10-15, evidence limited to local Python checks.
