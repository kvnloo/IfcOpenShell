# Lane 15 Wave 11 — IFC geometry unit parity (LOCAL_ONLY)

AI-assisted downstream research; no claims, default merges, upstream publications, or outside notifications.

## Finding and patch

IfcOpenShell's geometry kernel returns **metre-coordinate vertices by default** (`convert-back-units = False`), independently of the IFC file's length-unit scale. The previous local `verify_ifc()` implementation multiplied default kernel coordinates by `scale` again. This is invisible for metre-based IFC (scale 1) but would make a 10 m-long millimetre IFC appear 0.01 m long to the local validator (scale 0.001). This is a **source-confirmed error in our local checker**, not a measured upstream IfcOpenShell defect.

Patch: normalize IFC geometry-kernel vertices exactly once, explicitly set `convert-back-units=False`, and add an opt-in mm authoring mode and a native m/mm parity test. Native tests remain skipped until the actual IfcOpenShell runtime is available. Area and volume remain square/cubic metres in the mm variant; the IFC length unit alone switches to millimetres.

## Reproduction

```sh
python -m unittest discover -s . -p 'test_*.py' -v
(cd baseline && python -m unittest discover -s . -p 'test_*.py' -v)
python -m pytest -q test_ifc_units.py
python runtime_gate.py benchmarks/small_residence benchmarks/field_clinic benchmarks/workshop --report wave11-runtime-report.json --author-ifc
python ifc_author.py --length-unit mm --output wave11-mm-report
```

Observed: 75 pass + 1 native skip in root suite; 10/10 baseline pass; pytest 5 pass + 1 skip (38 subtests pass); three existing static building fixtures PASS, zero verified IFC or energy capabilities. Python 3.13 native `ifcopenshell`, pxr, EnergyPlus and Bonsai unavailable. `pip index versions ifcopenshell` failed with DNS name resolution, so an independent engine-verified IFC roundtrip did not run.

## Upstream source, authorship, and authorization

- IfcOpenShell v0.9.0 [geometry output unit contract](https://github.com/IfcOpenShell/IfcOpenShell/blob/v0.9.0/docs/ifcopenshell/geometry_settings.rst) and [shape utility](https://github.com/IfcOpenShell/IfcOpenShell/blob/v0.9.0/src/ifcopenshell-python/ifcopenshell/util/shape.py).
- The unrelated **upstream C++ unit-detection fix** is [BIMvoice's PR #9295](https://github.com/IfcOpenShell/IfcOpenShell/pull/9295); preserve credit and don't duplicate.
- [Factory AGENTS.md](https://github.com/kvnloo/oss-factory/blob/main/AGENTS.md), [CONTROL_PLANE](https://github.com/kvnloo/oss-factory/blob/main/factory/CONTROL_PLANE.md), [HITL](https://github.com/kvnloo/oss-factory/blob/main/factory/HITL.md); IFC project registration still draft [#100](https://github.com/kvnloo/oss-factory/pull/100), handoff [#104](https://github.com/kvnloo/oss-factory/issues/104).
- No worker slot or lease claimed. No GitHub writes. If future code is proposed to the IfcOpenShell library/Bonsai, apply LGPL-3.0-or-later/GPL-3.0-or-later respectively and the upstream AI-disclosure requirements.

## Next

In a compatible native environment, run `python -m unittest test_ifc_units.NativeMetreMillimetreRoundtripTests -v`. Verify authored/reopened IFC4 entities, schema, geometry kernel bounds and thermal boundary connections in both metres and millimetres; only then use Bonsai, native pxr and full EnergyPlus simulation to promote route capability.
