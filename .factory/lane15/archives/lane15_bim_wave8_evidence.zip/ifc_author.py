# This file was generated with the assistance of an AI coding tool.
"""Experimental IFC4 authoring + geometry-kernel gate for one thermal box.

Nominal thermal shell is 10 x 8 x 3 m. Physical IFC walls extend outside
its faces; slabs extend outside top/bottom. Thermal geometry is intentionally
not equated with material geometry. No energy loads are inferred.
"""
from __future__ import annotations

import argparse
from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path


@dataclass(frozen=True)
class Dimensions:
    length: float = 10.0
    width: float = 8.0
    height: float = 3.0
    wall: float = 0.2
    slab: float = 0.2

    def __post_init__(self):
        if any(not math.isfinite(v) or v <= 0 for v in vars(self).values()):
            raise ValueError("All dimensions must be finite and positive")
        if self.wall >= min(self.length, self.width) / 2 or self.slab >= self.height:
            raise ValueError("Thickness implausible relative to clear dimensions")


def bounds_from_endpoints(p1, p2, outward_thickness, height):
    """Compute bounds without the IFC geometry kernel: left is interior."""
    dx, dy = p2[0] - p1[0], p2[1] - p1[1]
    length = math.hypot(dx, dy)
    if length == 0:
        raise ValueError("Zero-length wall")
    outside = (dy / length * outward_thickness, -dx / length * outward_thickness)
    corners = [p1, p2, (p1[0] + outside[0], p1[1] + outside[1]),
               (p2[0] + outside[0], p2[1] + outside[1])]
    return ((min(p[0] for p in corners), min(p[1] for p in corners), 0.0),
            (max(p[0] for p in corners), max(p[1] for p in corners), height))


def pieces(d: Dimensions):
    l, w, h, t, s = d.length, d.width, d.height, d.wall, d.slab
    # CCW centerline tour: interior is on left, physical wall extends right.
    walls = {
        "South": ((0., 0.), (l, 0.)),
        "East": ((l, -t), (l, w+t)),
        "North": ((l, w), (0., w)),
        "West": ((0., w+t), (0., -t)),
    }
    result = []
    for name, (a, b) in walls.items():
        result.append({"name": name, "kind": "IfcWall", "p1": a, "p2": b,
                       "bbox": bounds_from_endpoints(a, b, t, h)})
    slab_xy = [(-t, -t), (l+t, -t), (l+t, w+t), (-t, w+t), (-t, -t)]
    result.extend([
        {"name": "Floor", "kind": "IfcSlab", "z": 0.0, "sense": "NEGATIVE",
         "polyline": slab_xy, "bbox": ((-t, -t, -s), (l+t, w+t, 0.0))},
        {"name": "Roof", "kind": "IfcSlab", "z": h, "sense": "POSITIVE",
         "polyline": slab_xy, "bbox": ((-t, -t, h), (l+t, w+t, h+s))},
    ])
    return result


def expected(d: Dimensions):
    return {
        "zone_floor_area_m2": d.length * d.width,
        "zone_shell_area_m2": 2 * (d.length * d.width + d.length * d.height + d.width * d.height),
        "zone_volume_m3": d.length * d.width * d.height,
        "physical_bbox_m": [[-d.wall, -d.wall, -d.slab],
                             [d.length+d.wall, d.width+d.wall, d.height+d.slab]],
        "physical_solid_count": 6,
        "energy_demand_kwh": None,
    }


def matrix_for_wall(p1, p2, np):
    dx, dy = p2[0] - p1[0], p2[1] - p1[1]
    length = math.hypot(dx, dy)
    if length <= 0:
        raise ValueError("Zero-length wall")
    ux, uy = dx / length, dy / length
    return np.array([[ux, -uy, 0, p1[0]], [uy, ux, 0, p1[1]],
                     [0, 0, 1, 0], [0, 0, 0, 1]], dtype=float)


def author(path: Path, d: Dimensions):
    import numpy as np
    import ifcopenshell
    import ifcopenshell.api.project
    import ifcopenshell.api.root
    import ifcopenshell.api.unit
    import ifcopenshell.api.context
    import ifcopenshell.api.aggregate
    import ifcopenshell.api.geometry
    import ifcopenshell.api.spatial
    import ifcopenshell.util.unit

    model = ifcopenshell.api.project.create_file(version="IFC4")
    project = ifcopenshell.api.root.create_entity(model, ifc_class="IfcProject", name="Lane15 Reference")
    units = [ifcopenshell.api.unit.add_si_unit(model, unit_type=kind)
             for kind in ("LENGTHUNIT", "AREAUNIT", "VOLUMEUNIT")]
    ifcopenshell.api.unit.assign_unit(model, units=units)
    assert math.isclose(ifcopenshell.util.unit.calculate_unit_scale(model), 1.0)
    context = ifcopenshell.api.context.add_context(model, context_type="Model")
    body = ifcopenshell.api.context.add_context(model, context_type="Model", context_identifier="Body",
                                               target_view="MODEL_VIEW", parent=context)
    site = ifcopenshell.api.root.create_entity(model, ifc_class="IfcSite", name="Reference Site")
    building = ifcopenshell.api.root.create_entity(model, ifc_class="IfcBuilding", name="Reference Building")
    storey = ifcopenshell.api.root.create_entity(model, ifc_class="IfcBuildingStorey", name="Ground")
    space = ifcopenshell.api.root.create_entity(model, ifc_class="IfcSpace", name="TestZone")
    for child, parent in ((site, project), (building, site), (storey, building), (space, storey)):
        ifcopenshell.api.aggregate.assign_object(model, products=[child], relating_object=parent)
    for spec in pieces(d):
        element = ifcopenshell.api.root.create_entity(model, ifc_class=spec["kind"], name=spec["name"])
        if spec["kind"] == "IfcWall":
            p1, p2 = spec["p1"], spec["p2"]
            rep = ifcopenshell.api.geometry.add_wall_representation(
                model, context=body, length=math.dist(p1, p2),
                height=d.height, thickness=d.wall, direction_sense="NEGATIVE")
            matrix = matrix_for_wall(p1, p2, np)
        else:
            rep = ifcopenshell.api.geometry.add_slab_representation(
                model, context=body, depth=d.slab,
                polyline=spec["polyline"], direction_sense=spec["sense"])
            matrix = np.eye(4)
            matrix[2, 3] = spec["z"]
        ifcopenshell.api.geometry.assign_representation(model, product=element, representation=rep)
        ifcopenshell.api.spatial.assign_container(model, products=[element], relating_structure=storey)
        ifcopenshell.api.geometry.edit_object_placement(model, product=element, matrix=matrix)
    path.parent.mkdir(parents=True, exist_ok=True)
    model.write(str(path))
    return path


def verify_ifc(path: Path, d: Dimensions):
    """Saved/reloaded EXPRESS validation and independently meshed solid bounds."""
    import ifcopenshell
    import ifcopenshell.geom
    import ifcopenshell.util.unit
    import ifcopenshell.validate
    import numpy as np

    reopened = ifcopenshell.open(str(path))
    if reopened.schema != "IFC4":
        raise AssertionError(f"Unexpected schema: {reopened.schema}")
    counts = {k: len(reopened.by_type(k)) for k in
              ("IfcProject", "IfcSite", "IfcBuilding", "IfcBuildingStorey", "IfcSpace", "IfcWall", "IfcSlab")}
    if counts != {"IfcProject": 1, "IfcSite": 1, "IfcBuilding": 1, "IfcBuildingStorey": 1,
                  "IfcSpace": 1, "IfcWall": 4, "IfcSlab": 2}:
        raise AssertionError(f"IFC population mismatch: {counts}")
    scale = ifcopenshell.util.unit.calculate_unit_scale(reopened)
    if not math.isclose(scale, 1.0, abs_tol=1e-12):
        raise AssertionError(f"Wrong IFC length unit scale: {scale}")
    logger = ifcopenshell.validate.json_logger()
    ifcopenshell.validate.validate(str(path), logger)
    if logger.statements:
        raise AssertionError(f"IFC validation errors: {logger.statements[:3]}")
    settings = ifcopenshell.geom.settings()
    settings.set(settings.USE_WORLD_COORDS, True)
    bboxes = {}
    for spec in pieces(d):
        products = [o for o in reopened.by_type(spec["kind"]) if o.Name == spec["name"]]
        if len(products) != 1:
            raise AssertionError(f"Missing/duplicate named product: {spec['name']}")
        shape = ifcopenshell.geom.create_shape(settings, products[0])
        verts = np.asarray(shape.geometry.verts, dtype=float).reshape((-1, 3)) * scale
        low, high = verts.min(axis=0), verts.max(axis=0)
        target_low, target_high = spec["bbox"]
        if not np.allclose(low, target_low, atol=2e-4, rtol=0) or not np.allclose(high, target_high,
                                                                                   atol=2e-4, rtol=0):
            raise AssertionError(f"IFC solid bbox mismatch {spec['name']}: {low}/{high}, expected {spec['bbox']}")
        bboxes[spec["name"]] = [low.tolist(), high.tolist()]
    return {"schema": reopened.schema, "ifc_unit_scale_m": scale, "ifc_entities": counts,
            "validation_errors": 0, "geometry_kernel_bounds_m": bboxes, "kernel_bodies_checked": 6}


def run(output: Path, d: Dimensions):
    report = {"status": "blocked", "reference": expected(d), "tool": "IfcOpenShell authoring/runtime gate",
              "runtime_checks": {"ifc_roundtrip": "NOT_RUN", "schema_validation": "NOT_RUN",
                                 "geometry_kernel": "NOT_RUN", "bonsai": "NOT_RUN",
                                 "openusd": "NOT_RUN", "energyplus": "NOT_RUN", "energy_space_boundaries": "NOT_RUN"}}
    output.mkdir(parents=True, exist_ok=True)
    try:
        import ifcopenshell
    except ImportError:
        report["blocker"] = "ifcopenshell Python package not installed; no .ifc file produced"
    else:
        path = author(output / "single_zone.ifc", d)
        details = verify_ifc(path, d)
        from energy_handoff_gate import audit_model
        boundary_report = audit_model(ifcopenshell.open(str(path)))
        report["energy_space_boundary_audit"] = boundary_report
        report["runtime_checks"]["energy_space_boundaries"] = boundary_report["status"]
        report.update({"status": "ifc_authoring_verified", "ifcopenshell_version": ifcopenshell.version,
                       "verified": details, "sha256_ifc": hashlib.sha256(path.read_bytes()).hexdigest()})
        report["runtime_checks"].update({"ifc_roundtrip": "PASS", "schema_validation": "PASS",
                                          "geometry_kernel": "PASS"})
    (output / "ifc_report.json").write_text(json.dumps(report, indent=2) + "\n")
    return report


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--output", type=Path, default=Path("out"))
    args = ap.parse_args()
    print(json.dumps(run(args.output, Dimensions()), indent=2))
