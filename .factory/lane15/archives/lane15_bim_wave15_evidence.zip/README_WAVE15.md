<!-- This document was generated with the assistance of an AI coding tool. -->
# Lane 15 · Wave 15 — Fail-closed EnergyPlus zone and geometry-rule preflight

**Disposition:** `LOCAL_ONLY` / `LIMITED`. Downstream-only analysis and tests. No claim/lease, registry merge, GitHub write, origin-facing action, or verified construction/energy outcome.

## Problem reproduced

The Wave 14 **synthetic EnergyPlus IDF fragment parser** accepted five invalid or unsafe variations while still returning six surfaces:

1. Missing thermal `Zone` object.
2. Surface references `TestZone`, but only `WrongZone` exists.
3. Duplicate `Zone, TestZone` definition.
4. `GlobalGeometryRules` says `WorldRelative` (was accepted as a prefix match for `World`).
5. A second conflicting `GlobalGeometryRules` object is present.

These corruptions can make a static geometry receipt look complete when the IDF's thermal zone or world-coordinate contract is not. This is **a bug in this local fixture preflight**, not evidence of an EnergyPlus or IfcOpenShell upstream bug.

## Patch

Minimal changes to `baseline/test_export_invariants.py` require exactly one `GlobalGeometryRules` with the expected first three fields and exactly one declared `Zone` named `TestZone`. Added negative tests to the fixture parser and to `runtime_gate.py` end-to-end static preflight tests. No surface vertices, IDs, metrics, or IFC authoring paths were altered.

- `wave15-local.patch` applies (`patch --dry-run -p1`) to the Wave 14 archive.
- `provenance/wave14_test_export_invariants.py` is an unchanged baseline copy to make before/after reproduction self-contained.
- `repro_idf_structure.py` and `wave15-before-after.json` show all 5 previously accepted mutations now rejected.

## Verification (executed)

```bash
PYTHONPATH=baseline:. python repro_idf_structure.py
python -m unittest discover -s . -p 'test_*.py' -q
(cd baseline && python -m unittest discover -s . -p 'test_*.py' -q)
python -m pytest -q test_runtime_gate.py baseline/test_export_invariants.py
python runtime_gate.py benchmarks/small_residence benchmarks/field_clinic benchmarks/workshop \
  --author-ifc --ifc-units both --report wave15-runtime-report.json
```

- Primary unittest: **89 total, 88 passed, 1 skipped** (native IfcOpenShell).
- Baseline unittest: **15 passed**. Across disjoint suites, **103 passed, 1 skipped**.
- Pytest focused rerun: **36 passed, 131 subtests passed**; overlaps the unittest total.
- Five baseline parser false accepts → five corrected rejects; valid fixture still accepted.
- Three analytic geometry preflights passed, **zero construction capabilities verified**.

## Runtime and policy limits

- `ifcopenshell` and `pxr` are absent; neither `IfcConvert` nor `energyplus` executable was found. Native IFC4 metre/mm round-trip, Bonsai inspection, real OpenUSD parse, EnergyPlus IDF validation, and energy simulation remain **NOT_RUN**.
- The IDF still contains undefined placeholder constructions and no complete schedules/weather/loads. It is **not** a runnable building-energy model. The parser checks a deliberately narrow generated grammar, not every valid EnergyPlus IDF.
- Canonical registry `factory/projects.json` has no merged IfcOpenShell entry. Existing [draft registry PR #100](https://github.com/kvnloo/oss-factory/pull/100) and [work order #104](https://github.com/kvnloo/oss-factory/issues/104) already describe the lane; neither was duplicated or changed.
- Factory policy read: `AGENTS.md`, `factory/CONTROL_PLANE.md`, `factory/HITL.md`, `factory/projects.json`. IFC upstream `AGENTS.md` read. No global worker slot claimed; project entry remains draft and upstream permission unknown.

## Credit and references

- The original IFC geometry/unit problem #9294 was reported by **joepaddock-uk** and the non-overlapping upstream fix PR #9295 belongs to **BIMvoice**. This local static IDF check neither replaces nor duplicates that work.
- EnergyPlus *Input Output Reference*: `Zone` definitions and `GlobalGeometryRules` establish thermal zone references and surface coordinate interpretation. https://bigladdersoftware.com/epx/docs/9-6/input-output-reference/group-thermal-zone-description-geometry.html
- IfcOpenShell AI contribution guidance: https://github.com/IfcOpenShell/IfcOpenShell/blob/v0.9.0/AGENTS.md
- Prototype code, mutation tests, and this report created with AI assistance; the factory's previous artifact and originating contributors retain their provenance.

## Next action

Review pending project routing PR #100 and available global claims **before** claiming work. On a host with IfcOpenShell/IfcConvert and `pxr`, run an actual metre/mm IFC4 geometry-kernel round-trip; independently parse the USDA scene and complete/run an EnergyPlus input (with valid constructions, schedules, climate and output requests). Preserve separate geometric and energy capabilities in the Civ handoff.
