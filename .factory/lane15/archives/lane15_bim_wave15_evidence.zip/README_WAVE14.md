<!-- This document was generated with the assistance of an AI coding tool. -->
# Lane 15 — Wave 14: reject false-positive USD length units

**Scope:** LOCAL_ONLY, synthetic IFC → OpenUSD → EnergyPlus geometry preflight. No GitHub writes, origin comments, worker claim/lease, default-branch merge, energy-savings statement, or native simulation.

## Defect and correction

The existing `parse_usda()` geometry QA used substring membership to validate `metersPerUnit = 1`. It accepted `metersPerUnit = 1000`, `1e3`, `1.5`, `1e-3`, and `1.0001`. A valid six-face geometry therefore obtained static `PASS` **even though stage units were wrong**. The discrepancy was reproduced against the previous Wave 13 source, not inferred.

The fix requires exactly one explicitly parsed, finite metre scale equal to 1.0 and exactly one Z up-axis. It also accepts valid equivalent numeric syntax (`1.0`, `1e0`). New regression cases check invalid scales, repeated metadata, wrong axis, and rejection through the end-to-end static gate. No source/mesh/thermal geometry was changed.

## Evidence: executed here

```
python -m unittest discover -s . -p 'test_*.py' -q
# 87 tests, OK (1 skipped: native IfcOpenShell)
(cd baseline && python -m unittest discover -s . -p 'test_*.py' -q)
# 13 tests, OK
python -m pytest -q test_runtime_gate.py baseline/test_export_invariants.py
# 32 passed, 125 subtests (overlaps unittest)
python runtime_gate.py benchmarks/small_residence benchmarks/field_clinic benchmarks/workshop \
  --author-ifc --ifc-units both --report wave14-runtime-report.json
# 3 geometry preflights passed; 0 verified capabilities
```

`wave14-before-after.json` contains the old-vs-new mutated unit acceptance matrix. `wave14-local.patch` is the exact change from Wave 13 and passed `patch -p1 --dry-run` on the Wave 13 snapshot. The package carries scripts, three synthetic fixtures, command logs, and per-fixture receipts.

## Status / blockers

**STATIC GEOMETRY PASS only** for small residence (129.6 m³), field clinic (777.6 m³), workshop (4200 m³). Native IfcOpenShell, pxr/OpenUSD, Bonsai GUI, and EnergyPlus executable were not available in this environment. The IDF is a *geometry-only fragment* with placeholder constructions. No valid operational energy model, native IFC4 round-trip, physical quantity measurement, or realized construction capability has been demonstrated.

The `kvnloo/oss-factory` control plane was read (AGENTS.md, factory/projects.json, factory/CONTROL_PLANE.md, factory/HITL.md). The canonical registry does **not** yet list IFC/Bonsai; pending proposed intake is tracked in factory PR #100 and existing work order #104. No new project registration, lease, or source publication was attempted. Origin IfcOpenShell AGENTS.md was read: LGPL-3.0-or-later library, GPL-3.0-or-later Bonsai, AI disclosure and small PRs. The IFC library unit-scale issue #9294 was reported by joepaddock-uk; the existing upstream fix PR #9295 was authored by BIMvoice. This local QA correction is different and is **not** an upstream bug report.

**Next:** Run the actual `--author-ifc --ifc-units both` receipt on a host with compatible IfcOpenShell wheels and geometry kernel; independently open USD via `pxr` and complete/run a valid EnergyPlus model before promoting verified capability. Review registry PR #100 and global worker claims first.

## References

- https://github.com/kvnloo/oss-factory/issues/104
- https://github.com/kvnloo/oss-factory/pull/100
- https://github.com/IfcOpenShell/IfcOpenShell/blob/main/AGENTS.md
- https://github.com/IfcOpenShell/IfcOpenShell/pull/9295
- https://github.com/IfcOpenShell/IfcOpenShell/issues/9294
