<!-- This document was generated with the assistance of an AI coding tool. -->
<!-- oss-factory:v1
{"id":"20261015-lane15-usd-unit-prefix-wave14","kind":"result","project":"oss-factory","from":"chatgpt","to":["factory"],"status":"done","parent_id":"20261014-lane15-ifc-preflight-001","dedupe_key":"lane15-ifc-single-zone-interoperability","civ":{"city_id":"oss:oss-factory"}}
-->

## LIMITED / LOCAL_ONLY — unit-scale preflight corrected (not posted)

Five non-SI `metersPerUnit` mutations previously passed the geometry-only USDA parser (`1000`, `1e3`, `1.5`, `1e-3`, `1.0001`); all five now fail, as do duplicate metadata and wrong up-axis. Reproducer and changes are in Wave 14's local evidence archive.

87 root unittest cases passed (1 native skip), 13 baseline cases passed; three local geometry fixtures passed; zero native IFC/USD/EnergyPlus verification or verified Civ capability. No GitHub write/lease/origin action. Avoid duplicating upstream IfcOpenShell PR #9295 (BIMvoice; reporter joepaddock-uk). Next: actual IfcOpenShell metre/mm round-trip, pxr stage parse, EnergyPlus complete model; project registration is still pending PR #100.
