<!-- This document was generated with the assistance of an AI coding tool. -->
<!-- oss-factory:v1
{"id":"20261015-lane15-idf-untracked-objects-021","kind":"result","project":"oss-factory","from":"chatgpt","to":["factory"],"status":"done","civ":{"city_id":"oss:oss-factory"},"parent_id":"20261014-lane15-ifc-preflight-001","dedupe_key":"lane15-ifc-single-zone-interoperability"}
-->

# Lane 15 — Wave 21: stop certifying unseen EnergyPlus geometry and loads

**Disposition: LOCAL_ONLY / LIMITED.** Independently reproduced a previously accepted invalid change to the *local* IFC→USDA→EnergyPlus synthetic handoff, wrote a bounded static-parser fix, ran tests and preserved RED/GREEN evidence. This is **not an upstream EnergyPlus/IfcOpenShell defect**. The static parser explicitly supports only the current geometry-only fragment, not general IDF syntax.

## Failure & why it matters

The existing `baseline/test_export_invariants.py:parse_idf` extracted six `BuildingSurface:Detailed` surfaces and ignored **all other EnergyPlus object types**. In an actual model, `FenestrationSurface:Detailed`/`Window`/`Door` modifies the opaque-vs-glazed envelope, `Shading:Building:Detailed` changes solar exposure, and `ZoneInfiltration:DesignFlowRate`/`Lights` introduces heat/airflow loads. A file with these extra objects still passed the original six-face crosswalk. One benchmark with a newly appended `FenestrationSurface:Detailed` also passed the full original `runtime_gate.check_case`, giving an apparently clean geometry packet while failing to account for the opening.

The patch makes the dependency-free preflight **fail closed on unsupported IDF objects**. It accepts the exporter’s `GlobalGeometryRules`, `Zone`, and `BuildingSurface:Detailed` objects only. Any richer IDF must move to an EnergyPlus-native parser/energy-boundary review. This preserves all existing geometry tests and intentionally rejects a valid *full EnergyPlus model* if supplied to the narrow static checker; that prevents misrepresenting it as the same opaque reference fixture.

## Observed measurements (October 15, 2026)

| Check | Before (Wave 20) | After (Wave 21) |
| --- | --- | --- |
| Static IDF with extra `Window` | accepted | rejected |
| Extra `FenestrationSurface:Detailed` | accepted | rejected |
| Extra shading / infiltration / interior loads | accepted | rejected |
| Full `runtime_gate.check_case` with injected aperture | accepted | rejected |
| New focused tests (3 methods, 8 mutation subcases) | 9 assertion failures | **3 pass; 8/8 rejected** |
| Core unittest suite | 109 run; 1 skipped | **112 run; 1 skipped** |
| Independent baseline tests | 19 pass | **19 pass** |
| Clean-apply rerun | — | **112 core tests pass (1 skip), 19 baseline pass** |
| Small residence, field clinic, workshop | static PASS | **3/3 static PASS** |
| Native IFC4 / OpenUSD / EnergyPlus | NOT_RUN | **NOT_RUN** |
| Real kWh or physical building improvement | unknown | **unknown** |

Baseline RED log: `evidence/wave21-red.log` (nine failures: 8 object mutation cases + runtime packet injection). GREEN logs: `evidence/wave21-green-targeted.log`, `evidence/wave21-green-core.log`, `evidence/wave21-green-baseline.log`; clean-apply logs provided. Machine-readable summary: `wave21-evidence.json`, `evidence/wave21-static-runtime-report.json`. Full tests include prior topology/IFC synthetic gates.

## Reproduce (from this ZIP)

```bash
unzip lane15_bim_wave21_evidence.zip -d wave21
cd wave21
PYTHONPATH=baseline:. python -m unittest test_idf_scope_gate.py -v
PYTHONPATH=baseline:. python -m unittest discover -s . -p 'test_*.py' -q
(cd baseline && PYTHONPATH=..:. python -m unittest discover -s . -p 'test_*.py' -q)
PYTHONPATH=baseline:. python runtime_gate.py \
  benchmarks/small_residence benchmarks/field_clinic benchmarks/workshop \
  --report evidence/reproduction-static-runtime-report.json
```

`wave21-local.patch` is a standalone patch against [Wave 20 ZIP](../lane15_bim_wave20_evidence.zip) containing only the modified parser and new tests. Its `git apply --check`, apply and both test commands succeeded on a clean extraction of Wave 20.

## Scope, provenance and authorization

Canonical [factory AGENTS.md](https://github.com/kvnloo/oss-factory/blob/main/AGENTS.md), [control plane](https://github.com/kvnloo/oss-factory/blob/main/factory/CONTROL_PLANE.md), [HITL](https://github.com/kvnloo/oss-factory/blob/main/factory/HITL.md), [registry](https://github.com/kvnloo/oss-factory/blob/main/factory/projects.json), and [IfcOpenShell AGENTS.md v0.9.0](https://github.com/IfcOpenShell/IfcOpenShell/blob/v0.9.0/AGENTS.md) were read. Continue existing [Lane 15 issue #104](https://github.com/kvnloo/oss-factory/issues/104); project registration is proposed by unmerged [draft #100](https://github.com/kvnloo/oss-factory/pull/100). **No new global worker claim or GitHub write was made.** Previous Wave 20 work remains credited, not silently replaced. Code/tests in this wave were AI-assisted; IfcOpenShell library authors and Bonsai/Blender, OpenUSD and EnergyPlus contributors retain their original credit and licenses. IfcOpenShell's library is LGPL-3.0-or-later and Bonsai is GPL-3.0-or-later, per their current AGENTS.

The eight synthetic IDF mutation cases are **local contract implementation evidence**, not a real customer impact claim or validation of an upstream requirement. No origin promotion justified. No energy consumption was simulated; `Civilization` remains `UNVERIFIED`.

## Next top-priority native gate

The sandbox lacks `ifcopenshell`, `pxr`, `IfcConvert`, Blender/Bonsai and `energyplus`; the PyPI index is unreachable here. Create a pinned, authorized downstream CI harness to (1) produce IFC4 metre and millimetre buildings, reopen them through the IfcOpenShell 0.9.0 schema and geometry kernel, (2) parse the USDA with real OpenUSD, (3) parse an EnergyPlus-ready IDF with native EnergyPlus before any simulation conclusion, (4) compare six surfaces/areas/thermal boundaries against the same reference and record exact SHA/versioned output. Do not bypass review/lease/approval gates to schedule a run or push the patch.

**Trade-route handoff:** Manufacturing material boxes (analytical quantities only) → IFC4 shell (native unverified) → OpenUSD shell (static only) → EnergyPlus fragment (static only) → Civilization state `UNVERIFIED`.
