# This file was generated with the assistance of an AI coding tool.
"""Negative-control study: four USD subdivision edits across three building fixtures.

Only exercises the dependency-free local static geometry gate; never claims
native USD, IFC, EnergyPlus or Bonsai verification.
"""
from __future__ import annotations

import json
from pathlib import Path
import shutil
import sys
from tempfile import TemporaryDirectory

sys.path.insert(0, str(Path(__file__).resolve().parent))
from runtime_gate import check_case

HERE = Path(__file__).resolve().parent
SCHEME = '        uniform token subdivisionScheme = "none"'


def mutate(text: str, mutation: str) -> str:
    if mutation == "absent":
        return text.replace(SCHEME + "\n", "", 1)
    if mutation == "catmullClark":
        return text.replace(SCHEME, '        uniform token subdivisionScheme = "catmullClark"', 1)
    if mutation == "bilinear":
        return text.replace(SCHEME, '        uniform token subdivisionScheme = "bilinear"', 1)
    if mutation == "duplicate":
        return text.replace('def Mesh "Roof" {', 'def Mesh "Roof" {\n' + SCHEME, 1)
    raise ValueError(mutation)


def main() -> dict:
    observations = []
    for case in ("small_residence", "field_clinic", "workshop"):
        fixture = HERE / "benchmarks" / case
        with TemporaryDirectory() as work:
            tmp = Path(work) / case
            tmp.mkdir()
            for name in ("metrics.json", "single_zone.usda", "single_zone_geometry.idf"):
                shutil.copyfile(fixture / name, tmp / name)
            baseline = check_case(tmp)
            assert baseline["analytic_geometry"]["status"] == "PASS"
            source = (tmp / "single_zone.usda").read_text()
            for mutation in ("absent", "catmullClark", "bilinear", "duplicate"):
                changed = mutate(source, mutation)
                if changed == source:
                    raise AssertionError(f"Mutation not applied: {case}:{mutation}")
                (tmp / "single_zone.usda").write_text(changed)
                try:
                    check_case(tmp)
                except AssertionError as exc:
                    if "subdivision" not in str(exc):
                        raise
                    result = "REJECTED"
                else:
                    result = "FALSE_PASS"
                observations.append({"fixture": case, "mutation": mutation, "result": result})
    summary = {"domain": "local dependency-free static USDA gate", "positive_fixtures": 3,
               "negative_mutations": len(observations),
               "rejected": sum(o["result"] == "REJECTED" for o in observations),
               "observations": observations, "native_ifc_usd_energyplus_verified": False}
    if summary["rejected"] != summary["negative_mutations"]:
        raise AssertionError(summary)
    return summary


if __name__ == "__main__":
    print(json.dumps(main(), indent=2))
