<!-- This document was generated with the assistance of an AI coding tool. -->
# Lane 15 — Wave 18: reject implicit OpenUSD subdivision

**Disposition:** `LOCAL_ONLY / LIMITED`; standalone local patch + tests, not a GitHub commit or upstream contribution. No worker lease, factory merge, Linear permission or real building-performance claim.

## Reproduced defect and requirement

The Wave 17 dependency-free `parse_usda()` preflight accepted a synthetic building face when `subdivisionScheme` was removed, changed to `catmullClark` or `bilinear`, or duplicated. All four mutated scenes retained the control-point vertices, so the old validator still treated them as six exact polygon faces. This was a **local preflight false positive**, *not an IfcOpenShell or OpenUSD defect*.

OpenUSD's Mesh schema defaults to **Catmull–Clark subdivision** if the attribute is unauthored, and specifically requires `subdivisionScheme = "none"` for simple polygonal quads. Source: https://openusd.org/dev/user_guides/schemas/usdGeom/overview.html and https://openusd.org/dev/api/class_usd_geom_mesh.html. The local contract explicitly intends unsmoothed planar polygon faces; subdivision behavior cannot be ignored.

## Fix and verification

`wave18-local.patch` updates only the local static parser, the future native OpenUSD probe and two focused tests. It requires exactly one explicit `subdivisionScheme = "none"` per Mesh in the static preflight and checks the native `UsdGeom.Mesh.GetSubdivisionSchemeAttr()` value before claiming stage geometry PASS. The native branch is **source-only**, since `pxr` is not installed.

- **Red:** 4/4 controlled mutations incorrectly accepted in the original Wave 17 parser (`wave18-red.log`).
- **Green:** 4/4 mutations rejected, explicit equivalent `token subdivisionScheme = "none"` accepted (`wave18-focused-green.log`).
- **Cross-fixture:** 3 synthetic building fixtures pass unchanged; **12/12** mutations rejected (`wave18_mutant_matrix.py`, `wave18-mutant-matrix.json`).
- **Clean apply against Wave 17 ZIP:** 92 core tests: **91 passed, 1 skipped**; 19 independent baseline tests passed. Combined **110 passed, 1 native skip** (`wave18-cleanapply-*.log`).
- **Capability packet:** 3 geometry-only analytic preflights PASS; native IFC metre/mm, native OpenUSD, Bonsai and EnergyPlus NOT_RUN; **0 real Civilization capabilities verified** (`wave18-runtime-report.json`).

These are synthetic correctness checks, *not* measured energy efficiency, construction impact, or actual IFC/USD/IDF application runtime outcomes. The `single_zone_geometry.idf` remains an **incomplete fragment**, not a runnable thermal/loads simulation.

## Reproduce

```bash
unzip lane15_bim_wave17_evidence.zip -d wave17
cd wave17
patch -p1 < ../wave18-local.patch
PYTHONPATH=baseline:. python -m unittest discover -s . -p 'test_*.py' -q
(cd baseline && PYTHONPATH=..:. python -m unittest discover -s . -p 'test_*.py' -q)
PYTHONPATH=baseline:. python wave18_mutant_matrix.py
PYTHONPATH=baseline:. python runtime_gate.py \
  benchmarks/small_residence benchmarks/field_clinic benchmarks/workshop \
  --author-ifc --ifc-units both --report wave18-runtime-report.json
```

`wave18_mutant_matrix.py` is a new standalone file in this archive; copy it into the Wave 17 work directory before running the third command. The same directory structure, including benchmark files, is also available in this standalone Wave 18 ZIP.

## Factory and contributor provenance

Control plane read from current `kvnloo/oss-factory` main: [AGENTS.md](https://github.com/kvnloo/oss-factory/blob/main/AGENTS.md), [projects.json](https://github.com/kvnloo/oss-factory/blob/main/factory/projects.json), [CONTROL_PLANE.md](https://github.com/kvnloo/oss-factory/blob/main/factory/CONTROL_PLANE.md), and [HITL.md](https://github.com/kvnloo/oss-factory/blob/main/factory/HITL.md).

Existing [factory draft #100](https://github.com/kvnloo/oss-factory/pull/100) holds the provisional IfcOpenShell registry entry; it is **not merged** into canonical main. Existing deduplicated downstream [work order #104](https://github.com/kvnloo/oss-factory/issues/104) is the coordination thread. No additional registry edit, worker lease or GitHub write was made here. For future upstream contributions, respect [IfcOpenShell AGENTS.md](https://github.com/IfcOpenShell/IfcOpenShell/blob/v0.9.0/AGENTS.md): LGPL-3.0-or-later library / GPL-3.0-or-later Bonsai, focused PRs, explicit AI contribution disclosure. [BIMvoice's upstream PR #9295](https://github.com/IfcOpenShell/IfcOpenShell/pull/9295) already addresses the related IFC project-library units issue; no duplicate fix attempted. Original building fixtures and geometry logic were inherited from earlier Lane 15 work; this narrow Wave 18 patch and tests were developed with AI assistance.

## Remaining blockers and next action

The runtime lacks `ifcopenshell`, `pxr`, `IfcConvert`, Blender/Bonsai and EnergyPlus; local pip package-index DNS failed. The historical blocker is **execution environment access**, not a proven upstream incompatibility. Therefore, no native IFC4 metre/mm round-trip, real OpenUSD stage semantics, Bonsai inspection or EnergyPlus parsing/simulation was performed.

**Next:** on a host with pinned IfcOpenShell 0.9.x and OpenUSD Python bindings, execute both metre/mm IFC4 authoring and saved-model geometry-kernel verification, then run the actual OpenUSD stage probe against normal and subdivided fixtures. Validate the EnergyPlus fragment with the real parser; only later add constructions, design-day/weather, loads and annual energy output. Keep `geometry_ready` distinct from `simulation_verified` along the Manufacturing → IFC → OpenUSD → EnergyPlus → Civilization trade route.
