<!-- This document was generated with the assistance of an AI coding tool. -->
<!-- oss-factory:v1
{"id":"20261015-lane15-ifc-mesh-volume-019","kind":"result","project":"oss-factory","from":"chatgpt","to":["factory"],"status":"done","civ":{"city_id":"oss:oss-factory"},"parent_id":"20261014-lane15-ifc-preflight-001","dedupe_key":"lane15-ifc-single-zone-interoperability"}
-->

# Lane 15 — Wave 19: closed-solid IFC kernel volume gate

**Status: `LOCAL_ONLY / LIMITED`.** Standalone local patch/tests; **no GitHub writes**, upstream activity, worker claims, default-branch merges, or energy-consumption claims. The existing [`kvnloo/oss-factory` draft #100](https://github.com/kvnloo/oss-factory/pull/100) still contains the unmerged provisional IfcOpenShell registry entry. Coordination thread [#104](https://github.com/kvnloo/oss-factory/issues/104) already exists; do not create another mirror.

## Concrete bug in the local preflight

The Wave 18 IFC4 geometry-kernel validator compared the axis-aligned min/max vertex **bounds** of each wall/slab against a rectangular solid reference, but did not verify its actual mesh volume. A closed triangular wedge can have precisely the same `[0,1]³` bounds as a solid 1 m³ cube while containing only 0.5 m³. The existing bounding-box criterion would accept both. This is a **local validation blind spot**, not a confirmed bug in upstream IfcOpenShell, Bonsai, OpenUSD or EnergyPlus.

New `mesh_volume_gate.py` independently checks the saved IFC kernel's **actual triangulated mesh**: closed oriented manifold edges, nondegenerate faces, finite vertices, strictly positive signed volume and agreement with analytic physical-solid volume. `ifc_author.verify_ifc()` now applies it to all six walls/slabs *after* IFC4 reopen/schema validation and compares its result with upstream `ifcopenshell.util.shape.get_volume()` (independent quantity implementation). The shared `runtime_gate.py` receipt refuses IFC `PASS` unless both six-body volume ledgers and manifold coverage are complete. The metre/mm native parity gate also compares volumes, not just bounds.

This is specifically for **six small rectangular material solids**. It is not a general IFC mesh repair/validation algorithm; arbitrary IFC topology, curved/reparameterized faces, openings and material quantities are out of scope. Welding coincident vertices uses 1e-7 m; volume tolerances are 5e-4 relative / 1e-5 m³ absolute, and remain uncalibrated against a real IFC 0.9.x run.

## Reproducible results (sandbox, October 15, 2026)

| Evidence | Observed |
|---|---|
| Pre-change static bbox regression | Half-volume wedge shares cube bbox and passes previous bbox-only equality |
| New closed mesh/volume gate | Rejects same wedge: 0.5 versus 1.0 m³ |
| Core unittest discovery | **104 passed, 1 native test skipped** (105 collected) |
| Independent baseline tests | **19 passed** |
| Total executed successfully | **123 passed, 1 skipped** |
| Independent clean-apply rerun | **123 passed, 1 skipped**, same outcome |
| Deterministic synthetic matrix (`seed=1519`) | **256/256** full boxes accepted; **256/256** bbox-identical half-volume wedges rejected |
| Maximum observed synthetic box relative volume error | `5.684e-13` |
| Three building fixtures | Static geometry preflight PASS for small residence, field clinic, workshop |
| Native IFC metre/mm, Bonsai, OpenUSD stage, EnergyPlus | **NOT_RUN**; no native packages/executables |
| Verified Civilization construction capabilities | **0**, energy demand `null` |

The matrix only measures ideal analytic triangle meshes; do not extrapolate these numbers to typical IFC model geometry, performance or construction accuracy.

## Reproduce from previous ZIP

```bash
unzip lane15_bim_wave18_evidence.zip -d wave18
cd wave18
git apply ../wave19-local.patch     # works with git apply even outside a repository
PYTHONPATH=baseline:. python -m unittest discover -s . -p 'test_*.py' -q
(cd baseline && PYTHONPATH=..:. python -m unittest discover -s . -p 'test_*.py' -q)
PYTHONPATH=baseline:. python wave19_geometry_matrix.py
PYTHONPATH=baseline:. python runtime_gate.py \
  benchmarks/small_residence benchmarks/field_clinic benchmarks/workshop \
  --author-ifc --ifc-units both --report evidence/wave19-runtime-report.json
```

For a **native** IFC4 validation on a machine where a compatible IfcOpenShell 0.9.x Python wheel and dependencies are already installed, use the same `runtime_gate.py --author-ifc --ifc-units both` invocation. The `test_ifc_units.NativeMetreMillimetreRoundtripTests` test will automatically stop skipping and also check each unit variant's closed mesh volume. Treat any failure as a real experiment to diagnose, not as evidence of upstream fault without independent reproduction.

## Provenance / control-plane / authorization

Read current [AGENTS](https://github.com/kvnloo/oss-factory/blob/main/AGENTS.md), [projects](https://github.com/kvnloo/oss-factory/blob/main/factory/projects.json), [CONTROL_PLANE](https://github.com/kvnloo/oss-factory/blob/main/factory/CONTROL_PLANE.md), [HITL](https://github.com/kvnloo/oss-factory/blob/main/factory/HITL.md), and [IfcOpenShell AGENTS at v0.9.0](https://github.com/IfcOpenShell/IfcOpenShell/blob/v0.9.0/AGENTS.md). The provisional entry is still on draft #100; no new registry write was made. Under the global six-worker cap, **no capacity lease was obtained or inferred**. No origin-facing action was attempted. All files in this local diff were generated or altered with AI assistance.

IfcOpenShell's [geometry docs](https://docs.ifcopenshell.org/ifcopenshell-python/geometry_processing.html) specify flattened triangle indices in `shape.geometry.faces`, and [shape utilities](https://docs.ifcopenshell.org/autoapi/ifcopenshell/util/shape/index.html) document `get_volume()` in m³. Existing [`IfcProjectLibrary` units PR #9295](https://github.com/IfcOpenShell/IfcOpenShell/pull/9295) remains open as checked October 15, 2026; credit **BIMvoice** and original issue reporters. This wave does not reimplement their fix. No native building energy simulation or real-world impact is asserted.

## Blocker and next highest-value action

The sandbox has no `ifcopenshell`, `pxr`, `IfcConvert`, Bonsai/Blender or EnergyPlus executable. Therefore the newly wired **native** checks are *source-only/unverified*. A native wheel-capable executor is required. The next wave should stop growing static preflight checks and **execute real IFC4 metre and millimetre author→write→reopen→tessellate→watertightness/volume parity**, fix any resulting incompatibilities, then hand off the exact saved IFC/six USD meshes to Bonsai/OpenUSD and the EnergyPlus geometry parser before attempting a runnable load model.

Trade route state: Manufacturing/reference physical components → IFC geometric fixture (`NOT_RUN` native) → OpenUSD meshes (`PASS` static only) → EnergyPlus geometry fragment (`PASS` static only; **not runnable**) → Civilization (`UNVERIFIED`).
