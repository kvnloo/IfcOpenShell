<!-- This document was generated with the assistance of an AI coding tool. -->
# Lane 15 Wave 13 — metre/mm IFC proof integrity gate (LOCAL_ONLY)

*2026-10-15 UTC · sandbox only · no worker claim, GitHub write or origin publication.*

**Concrete change.** Extended `runtime_gate.py` to execute native IFC authoring in `m`, `mm`, or `both` modes, with separate saved IFC paths per unit. Each receipt must prove the exact file SHA-256, IFC4 schema, length-unit scale, six independently meshed solids with finite metre-coordinate bounds within 0.2 mm of the reference, and SI output. The `both` mode requires each receipt to pass **and** six kernel bounding boxes to agree within 0.2 mm. IfcOpenShell is not installed here, so no native parity PASS was observed.

**Thermal handoff correction.** A self-reported `GEOMETRY_READY_ONLY` label is no longer enough: the runtime status, geometry agreement flag, six named face areas, and zone volume must match the reference. This stops a mocked or incomplete report from upgrading bare topology to verified geometry. This is evidence integrity, **not** simulation verification.

## Reproduction

```sh
python -m unittest discover -s . -p 'test_*.py' -q
(cd baseline && python -m unittest discover -s . -p 'test_*.py' -q)
python -m pytest -q test_runtime_gate.py test_ifc_units.py
python runtime_gate.py benchmarks/small_residence benchmarks/field_clinic benchmarks/workshop --author-ifc --ifc-units both --report wave13-runtime-report.json
```

**Observed:** 85 tests passed, 1 skipped (root), 10 baseline tests passed; pytest subset 28 passed, 1 skipped, 52 subtests passed (**overlapping**, not additional). Three geometry-only fixture preflights passed: residence 129.6 m³ / 171.6 m² envelope, clinic 777.6 m³ / 648 m², workshop 4200 m³ / 1900 m². All six metre/mm authoring attempts returned `NOT_RUN`; parity, Bonsai, pxr, EnergyPlus, and Civilization capabilities remain unverified. No IFC file was generated. See JSON and command logs.

## Factory / licensing / credit

Factory AGENTS, `factory/CONTROL_PLANE.md`, `factory/HITL.md`, and the canonical registry were read from `kvnloo/oss-factory`. Registry entry remains draft PR #100; downstream issue #104 is the coordination point. No lease was acquired; this is isolated local evidence, not a downstream CI result. `IfcOpenShell/IfcOpenShell` `AGENTS.md` was consulted: library LGPL-3.0-or-later, Bonsai GPL-3.0-or-later, disclose AI-assisted code. No origin changes made. Existing IFC project-library unit-detection fix is in upstream PR #9295 by **BIMvoice**, building on issue #9294 by **joepaddock-uk**; this patch does not duplicate it.

**Next:** On a compatible runtime, run the command above with real IfcOpenShell and attach model hashes, kernel bbox measurements, boundary areas and metre/mm parity; then separately parse USDA through pxr and complete an EnergyPlus model with real weather, constructions, schedules, and engine execution. Do not promote synthetic results to construction/energy performance claims.
