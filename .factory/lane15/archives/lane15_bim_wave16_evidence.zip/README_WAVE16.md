<!-- This document was generated with the assistance of an AI coding tool. -->
# Lane 15 · Wave 16 — Fail-closed thermal boundary orientation receipt

**Disposition:** `LOCAL_ONLY` / `LIMITED`. Nothing published, claimed, merged or promoted.

## Confirmed local defect

The Wave 15 `validated_boundary_receipt()` accepted a saved IFC thermal-boundary
handoff even when its recorded outward normal for the roof was **inverted**;
its six areas, volume and high-level status could remain unchanged. It also
accepted contradictory topology findings (`invalid`, `missing`, `unexpected`,
`duplicate`, wrong boundary counts). This is a **local synthetic receipt
integrity defect**, not an IfcOpenShell or EnergyPlus upstream bug.

The thermal face orientation matters for unambiguous conversion of an IFC
space boundary into the face-winding contract shared by USDA and the static
EnergyPlus IDF fragment. Area alone does not prove the orientation.

## Patch and repro

`wave16-local.patch` changes only `runtime_gate.py` and `test_runtime_gate.py`.
The gate now checks all six outward normals against the analytic shell and
requires semantic topology counts and issue lists to agree with
`GEOMETRY_READY_ONLY`. It still does **not** claim simulated heat flow.

The new tests have **10 negative subcases** (four normal corruptions plus six
topology corruptions). Before the patch all 10 falsely returned
`GEOMETRY_READY_ONLY`; afterwards all 10 return `NOT_RUN`. The complete,
untampered synthetic receipt remains accepted by gate-logic tests only.

Apply to the previous Wave 15 artifact:

```sh
unzip lane15_bim_wave15_evidence.zip -d prior
cd prior
patch -p1 < ../wave16-local.patch
PYTHONPATH=baseline:. python -m unittest discover -s . -p 'test_*.py' -q
(cd baseline && python -m unittest discover -s . -p 'test_*.py' -q)
PYTHONPATH=baseline:. python -m pytest -q test_runtime_gate.py baseline/test_export_invariants.py
PYTHONPATH=baseline:. python runtime_gate.py benchmarks/small_residence benchmarks/field_clinic benchmarks/workshop \
    --author-ifc --ifc-units both --report wave16-runtime-report.json
```

## Observed verification

- Primary unittest: **91 run, 90 pass, 1 skip** (native IfcOpenShell).
- Separate baseline unittest: **15 pass**; combined disjoint total **105 pass, 1 skip**.
- Focused pytest rerun: **38 pass, 141 subtests** (overlaps unittest).
- Three fixture analytic checks pass, **zero native IFC, USD, Bonsai or
  EnergyPlus runtime checks verified**; Civilization capability remains `UNVERIFIED`.
- Logs: `wave16-red.log`, `wave16-green-focused.log`,
  `wave16-core-unittest.log`, `wave16-baseline-unittest.log`,
  `wave16-focused-pytest.log`, `wave16-runtime.log`.
- `wave16-evidence.json` contains file SHA256s and exact gate classifications.

## Control plane and attribution

Read [AGENTS](https://github.com/kvnloo/oss-factory/blob/main/AGENTS.md),
[CONTROL_PLANE](https://github.com/kvnloo/oss-factory/blob/main/factory/CONTROL_PLANE.md),
[HITL](https://github.com/kvnloo/oss-factory/blob/main/factory/HITL.md),
[registry](https://github.com/kvnloo/oss-factory/blob/main/factory/projects.json) and
[IfcOpenShell contributor conventions](https://github.com/IfcOpenShell/IfcOpenShell/blob/v0.9.0/AGENTS.md).
IfcOpenShell is LGPL-3.0-or-later; Bonsai is GPL-3.0-or-later. This independent
local validator patch is not an upstream code change.

The `ifcopenshell` registration remains in **draft**
[factory PR #100](https://github.com/kvnloo/oss-factory/pull/100), with existing
[work item #104](https://github.com/kvnloo/oss-factory/issues/104); neither was
touched. No global worker lease, GitHub write, or origin authorization assumed.
Upstream units issue [#9294](https://github.com/IfcOpenShell/IfcOpenShell/issues/9294)
and open [PR #9295](https://github.com/IfcOpenShell/IfcOpenShell/pull/9295)
are already owned; credit reporter **joepaddock-uk** and patch author **BIMvoice**.
Local code, tests, and report were produced with AI assistance; earlier
waves retain their provenance.

## Next

On a suitable host, inspect real serialized metre/mm IFC4 first-level
boundaries with IfcOpenShell + Bonsai, parse the USDA through `pxr`, and
run a completed EnergyPlus model (constructions, schedules, weather). Preserve
separate geometry and energy truth states; do not promote a static preflight.
