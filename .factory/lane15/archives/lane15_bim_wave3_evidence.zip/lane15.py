# This file was generated with the assistance of an AI coding tool.
"""Small, deliberately idealised IFC / OpenUSD / EnergyPlus geometry handoff fixture.

The thermal-zone reference shell is zero thickness; physical IFC walls/slabs
have thickness. Do not interpret this geometry-only preflight as an energy model.
"""

from __future__ import annotations

import argparse
from dataclasses import dataclass
import json
import math
from pathlib import Path

Point = tuple[float, float, float]


@dataclass(frozen=True)
class Building:
    length_m: float = 10.0
    width_m: float = 8.0
    height_m: float = 3.0
    wall_thickness_m: float = 0.2
    slab_thickness_m: float = 0.2

    def __post_init__(self) -> None:
        if any(not math.isfinite(value) or value <= 0 for value in vars(self).values()):
            raise ValueError("All dimensions must be finite and positive")
        if self.wall_thickness_m >= min(self.length_m, self.width_m) / 2:
            raise ValueError("Wall thickness exceeds this fixture's useful range")


@dataclass(frozen=True)
class Surface:
    name: str
    kind: str
    vertices: tuple[Point, Point, Point, Point]


def shell(b: Building) -> tuple[Surface, ...]:
    """Return six outward-facing thermal-zone reference polygons, in metres."""
    l, w, h = b.length_m, b.width_m, b.height_m
    return (
        Surface("Floor", "Floor", ((0, 0, 0), (0, w, 0), (l, w, 0), (l, 0, 0))),
        Surface("Roof", "Roof", ((0, 0, h), (l, 0, h), (l, w, h), (0, w, h))),
        Surface("South", "Wall", ((0, 0, 0), (l, 0, 0), (l, 0, h), (0, 0, h))),
        Surface("North", "Wall", ((l, w, 0), (0, w, 0), (0, w, h), (l, w, h))),
        Surface("East", "Wall", ((l, 0, 0), (l, w, 0), (l, w, h), (l, 0, h))),
        Surface("West", "Wall", ((0, w, 0), (0, 0, 0), (0, 0, h), (0, w, h))),
    )


def difference(a: Point, b: Point) -> Point:
    return (a[0] - b[0], a[1] - b[1], a[2] - b[2])


def cross(a: Point, b: Point) -> Point:
    return (a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0])


def area_vector(s: Surface) -> Point:
    p, q, r, t = s.vertices
    c1 = cross(difference(q, p), difference(r, p))
    c2 = cross(difference(r, p), difference(t, p))
    return tuple((a + b) / 2 for a, b in zip(c1, c2))  # type: ignore[return-value]


def area(s: Surface) -> float:
    return math.sqrt(sum(x * x for x in area_vector(s)))


def signed_enclosed_volume(surfaces: tuple[Surface, ...]) -> float:
    """Divergence-theorem volume: sum(area_vector · face_centroid) / 3."""
    total = 0.0
    for s in surfaces:
        center = tuple(sum(v[axis] for v in s.vertices) / 4 for axis in range(3))
        total += sum(a * c for a, c in zip(area_vector(s), center)) / 3
    return total


def quantities(b: Building) -> dict[str, object]:
    faces = shell(b)
    return {
        "fixture": "single-zone-rectangle-v1",
        "unit": "m",
        "dimensions_m": {"length": b.length_m, "width": b.width_m, "height": b.height_m},
        "floor_area_m2": area(faces[0]),
        "roof_area_m2": area(faces[1]),
        "wall_area_m2": sum(area(s) for s in faces if s.kind == "Wall"),
        "envelope_area_m2": sum(area(s) for s in faces),
        "enclosed_volume_m3": signed_enclosed_volume(faces),
        "energy_demand_kwh": None,
        "assumptions": [
            "Synthetic single-zone rectangular shell, no openings",
            "Reference thermal surfaces are zero thickness; IFC physical walls/slabs are thicker",
            "No construction layers, HVAC, schedules, climate/weather, or calibrated energy simulation",
        ],
    }


def write_usda(b: Building, dest: Path) -> None:
    lines = ["#usda 1.0", "(", '    upAxis = "Z"', "    metersPerUnit = 1", ")", '', 'def Xform "Building" {']
    for s in shell(b):
        points = ", ".join("(" + ", ".join(f"{v:.6f}" for v in p) + ")" for p in s.vertices)
        lines.extend([
            f'    def Mesh "{s.name}" {{',
            '        int[] faceVertexCounts = [4]',
            '        int[] faceVertexIndices = [0, 1, 2, 3]',
            f'        point3f[] points = [{points}]',
            '        uniform token subdivisionScheme = "none"',
            '    }',
        ])
    lines.extend(['}', ''])
    dest.write_text("\n".join(lines), encoding="utf-8")


def write_idf_fragment(b: Building, dest: Path) -> None:
    lines = [
        "! Geometry-only preflight: NOT a run-ready EnergyPlus simulation.",
        "! Synthetic construction names are unresolved by design; no energy claims.",
        "GlobalGeometryRules, UpperLeftCorner, CounterClockWise, World;",
        "Zone, TestZone, 0, 0, 0, 0, 1, 1, autocalculate, autocalculate;",
        "",
    ]
    for s in shell(b):
        exterior = "Ground" if s.kind == "Floor" else "Outdoors"
        sun = "NoSun" if s.kind == "Floor" else "SunExposed"
        wind = "NoWind" if s.kind == "Floor" else "WindExposed"
        construction = {"Floor": "FloorPlaceholder", "Roof": "RoofPlaceholder", "Wall": "WallPlaceholder"}[s.kind]
        fields = [s.name, s.kind, construction, "TestZone", exterior, "", sun, wind, "autocalculate", "4"]
        # Match UpperLeftCorner in the IDF header without changing wall winding.
        vertices = s.vertices[-1:] + s.vertices[:-1] if s.kind == "Wall" else s.vertices
        for x, y, z in vertices:
            fields.extend([f"{x:.6f}", f"{y:.6f}", f"{z:.6f}"])
        lines.extend(["BuildingSurface:Detailed,", "  " + ",\n  ".join(fields) + ";", ""])
    dest.write_text("\n".join(lines), encoding="utf-8")


def write_ifc(b: Building, dest: Path) -> None:
    """Optional IFC4 authoring adapter. Requires a real IfcOpenShell wheel.

    This integration has not been run in the ChatGPT container because
    IfcOpenShell/its geometry kernel cannot be installed without network access.
    """
    try:
        import numpy as np
        import ifcopenshell
        import ifcopenshell.api.aggregate
        import ifcopenshell.api.context
        import ifcopenshell.api.geometry
        import ifcopenshell.api.project
        import ifcopenshell.api.root
        import ifcopenshell.api.spatial
        import ifcopenshell.api.unit
    except ImportError as exc:
        raise RuntimeError("IFC generation requires: pip install ifcopenshell==0.9.0 numpy") from exc

    model = ifcopenshell.api.project.create_file(version="IFC4")
    project = ifcopenshell.api.root.create_entity(model, ifc_class="IfcProject", name="Lane 15 test building")
    metre = ifcopenshell.api.unit.add_si_unit(model, unit_type="LENGTHUNIT")
    area_unit = ifcopenshell.api.unit.add_si_unit(model, unit_type="AREAUNIT")
    volume_unit = ifcopenshell.api.unit.add_si_unit(model, unit_type="VOLUMEUNIT")
    ifcopenshell.api.unit.assign_unit(model, units=[metre, area_unit, volume_unit])
    context = ifcopenshell.api.context.add_context(model, context_type="Model")
    body = ifcopenshell.api.context.add_context(
        model, context_type="Model", context_identifier="Body", target_view="MODEL_VIEW", parent=context
    )
    site = ifcopenshell.api.root.create_entity(model, ifc_class="IfcSite", name="Synthetic site")
    building = ifcopenshell.api.root.create_entity(model, ifc_class="IfcBuilding", name="One-zone building")
    storey = ifcopenshell.api.root.create_entity(model, ifc_class="IfcBuildingStorey", name="Ground storey")
    space = ifcopenshell.api.root.create_entity(model, ifc_class="IfcSpace", name="TestZone")
    for parent, child in ((project, site), (site, building), (building, storey), (storey, space)):
        ifcopenshell.api.aggregate.assign_object(model, relating_object=parent, products=[child])

    # These are nominal wall centreline locations; the exterior/interior faces
    # differ from the idealised zero-thickness EnergyPlus reference shell.
    l, w, h = b.length_m, b.width_m, b.height_m
    edges = [((0, 0), (l, 0)), ((l, 0), (l, w)), ((l, w), (0, w)), ((0, w), (0, 0))]
    products = []
    for i, (p1, p2) in enumerate(edges, start=1):
        wall = ifcopenshell.api.root.create_entity(model, ifc_class="IfcWall", name=f"Wall{i}")
        rep = ifcopenshell.api.geometry.create_2pt_wall(
            model, element=wall, context=body, p1=p1, p2=p2, elevation=0.0,
            height=h, thickness=b.wall_thickness_m, is_si=True
        )
        ifcopenshell.api.geometry.assign_representation(model, product=wall, representation=rep)
        products.append(wall)

    perimeter = [(0.0, 0.0), (l, 0.0), (l, w), (0.0, w)]
    for name, z in (("FloorSlab", -b.slab_thickness_m), ("RoofSlab", h)):
        slab = ifcopenshell.api.root.create_entity(model, ifc_class="IfcSlab", name=name)
        matrix = np.eye(4)
        matrix[2, 3] = z
        ifcopenshell.api.geometry.edit_object_placement(model, product=slab, matrix=matrix)
        rep = ifcopenshell.api.geometry.add_slab_representation(
            model, context=body, depth=b.slab_thickness_m, polyline=perimeter
        )
        ifcopenshell.api.geometry.assign_representation(model, product=slab, representation=rep)
        products.append(slab)

    ifcopenshell.api.spatial.assign_container(model, relating_structure=storey, products=products)
    model.write(str(dest))
    reopened = ifcopenshell.open(str(dest))
    assert len(reopened.by_type("IfcWall")) == 4
    assert len(reopened.by_type("IfcSlab")) == 2
    assert len(reopened.by_type("IfcSpace")) == 1
    import ifcopenshell.util.unit
    assert math.isclose(ifcopenshell.util.unit.calculate_unit_scale(reopened), 1.0)


def build(dest: Path, *, with_ifc: bool = False, dimensions: Building | None = None) -> None:
    b = dimensions or Building()
    dest.mkdir(parents=True, exist_ok=True)
    write_usda(b, dest / "single_zone.usda")
    write_idf_fragment(b, dest / "single_zone_geometry.idf")
    (dest / "metrics.json").write_text(json.dumps(quantities(b), indent=2) + "\n", encoding="utf-8")
    if with_ifc:
        write_ifc(b, dest / "single_zone.ifc")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("out"))
    parser.add_argument("--with-ifc", action="store_true", help="requires IfcOpenShell 0.9.0 and NumPy")
    args = parser.parse_args()
    build(args.out, with_ifc=args.with_ifc)
