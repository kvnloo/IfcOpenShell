# Lane 15, Wave 3: IDF start-corner convention + independent mesh validation

AI-generated research/patch/tests. All outputs LOCAL ONLY; no new GitHub publication or upstream write.

## Observed mismatch (local exporter, not an upstream bug)
The existing `GlobalGeometryRules, UpperLeftCorner, CounterClockWise, World` IDF
header describes walls whose first vertex should be an upper-left corner,
but the existing four walls start at Z=0. Baseline test returned **4 failures**.
The patched exporter rotates the four wall cycles to begin at Z=3 (upper-left).
This does NOT alter winding, connectivity, position, area, or volume.
Cross-format equality must allow cyclic polygon rotations but still reject reversal.

Requirements reference: https://www.building-simulation-data.com/IDD-explorer/9.3.0/class/GLOBALGEOMETRYRULES

## Run
From `branch_equivalent/`, with Python 3.13 and `trimesh==4.11.1` installed:

```sh
python -m unittest discover -s . -p 'test_*.py' -v
python export_surfaces.py --out ../output
```

The separate original prototype can be tested with:

```sh
cd ..
python -m unittest test_export_roundtrip -v
```

## Evidence
- RED: `baseline_red.txt` (one test, four failing wall subtests)
- GREEN: `branch_tests.txt` (10 tests) and `extended_tests.txt` (5 tests)
- Independent Trimesh: 8 vertices, 12 triangles, watertight, 268 m² shell,
  240 m³ signed volume; reversed wall / missing roof / 1000x scale detected.
- Reference models: `output/` (USDA + incomplete IDF fragment).
- `export_surfaces.patch` applies **only** to the existing exporter on draft
  https://github.com/kvnloo/oss-factory/pull/100 ; accompanying tests remain
  LOCAL because the earlier `test_export_invariants.py` is not on that PR branch.
- No project-specific origin PR/comment, global six-worker claim, or merge.

## Limits and next step
IfcOpenShell, OpenUSD and EnergyPlus runtimes are unavailable; network Python
package install failed on DNS resolution. This is a source/export preflight,
NOT proof that EnergyPlus accepts the IDF or that loads are meaningful.
Physical IFC wall/slab faces differ from the zero-thickness zone shell.
Run actual IFC4 authoring, saved/reloaded geometry bounds and unit scale,
Bonsai inspection, OpenUSD stage parse, then EnergyPlus IDF/IDD and full-load
simulation with materials, schedules, weather and validated thermal boundaries.

Existing upstream unit-scale fix: BIMvoice's PR https://github.com/IfcOpenShell/IfcOpenShell/pull/9295 .
